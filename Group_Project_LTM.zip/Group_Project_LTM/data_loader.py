"""
XJTU-SPS Data Loader — AD (MonitorAgent) + FD (DiagnosisAgent)
================================================================
Loads AD (anomaly detection) and FD (fault diagnosis) datasets from
the XJTU-SPS collection, assigns labels, and prepares unified
train/test DataFrames ready for windowing + model training.

Expected directory layout (adjust ROOT paths below):

XJTU-SPS for AD/
    AD_Train.pkl                  (normal telemetry only)
    AD_Test.pkl                   (mixed normal/anomaly telemetry)
    AD_Test_AnomalyLabel.pkl      (labels aligned to AD_Test, if separate)

XJTU-SPS for FD/
    BAT_degradation/
        BAT_degradation_Train.pkl
        BAT_degradation_Test.pkl
    SA_partial_open/
        SA_partial_open_Train.pkl
        SA_partial_open_Test.pkl
    ... (18 folders total, including Normal)
"""

import pandas as pd
from pathlib import Path

# ---------------------------------------------------------------------------
# CONFIG — defaults to local workspace directories, or override if needed
# ---------------------------------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent

def _find_dir(parent: Path, candidate_names: list[str]) -> Path:
    for name in candidate_names:
        p = parent / name
        if p.exists() and p.is_dir():
            return p
    for pattern in candidate_names:
        matches = [d for d in parent.iterdir() if d.is_dir() and pattern.lower() in d.name.lower()]
        if matches:
            return matches[0]
    return parent / candidate_names[0]

AD_ROOT = _find_dir(BASE_DIR, ["XJTU-SPS For AD", "XJTU-SPS for AD"])
FD_ROOT = _find_dir(BASE_DIR, ["XJTU-SPS for FD", "XJTU-SPS For FD"])

SENSOR_COLUMNS = [
    "U_SA", "I_SA", "P_SA",
    "U_Load_output", "I_Load_output", "P_Load_output",
    "U_BCR", "I_BCR", "P_BCR",
    "U_BAT2", "I_BAT2", "T_BAT2",
    "U_BAT3", "I_BAT3", "T_BAT3",
    "U_BAT4", "I_BAT4", "T_BAT4",
    "U_Bus", "I_Bus", "P_Bus",
    "U_Load1", "I_Load1", "T_Load1", "P_Load1",
    "U_Load2", "I_Load2", "T_Load2", "P_Load2",
    "U_Load3", "I_Load3", "T_Load3", "P_Load3",
]

# 18-class label map: folder name -> integer label.
# 0 is reserved for Normal.
FD_CLASS_MAP = {
    "Normal": 0,
    "SA_partial component or branch open circuit": 1,
    "SA_partial component or branch short circuit": 2,
    "SA_component deterioration": 3,
    "BCR_open circuit": 4,
    "BCR_short circuit": 5,
    "BCR_increased power loss": 6,
    "BAT_degradation": 7,
    "BAT_open circuit": 8,
    "Bus_open circuit": 9,
    "Bus_short circuit": 10,
    "Bus_insulation breakdown": 11,
    "PDM1_open circuit or short circuit": 12,
    "PDM2_open circuit or short circuit": 13,
    "PDM3_open circuit or short circuit": 14,
    "Load1_open circuit": 15,
    "Load2_open circuit": 16,
    "Load3_open circuit": 17,
}


def _find_file(root: Path, candidates: list[str], pattern: str = None) -> Path:
    for name in candidates:
        p = root / name
        if p.exists():
            return p
    if pattern:
        matches = list(root.glob(pattern))
        if matches:
            return matches[0]
    return root / candidates[0]


# ---------------------------------------------------------------------------
# AD LOADER — MonitorAgent
# ---------------------------------------------------------------------------
def load_ad_data(ad_root: Path = AD_ROOT):
    """
    Loads AD_Train (normal only) and AD_Test (+ labels if present).
    Returns: train_df, test_df
    Both have a 'label' column: 0 = normal, 1 = anomaly.
    """
    train_path = _find_file(ad_root, ["AD_Train.pkl", "XJTU-SPS%20for%20AD_Train.pkl"], "*Train*.pkl")
    test_path = _find_file(ad_root, ["AD_Test.pkl", "XJTU-SPS%20for%20AD_Test.pkl"], "*Test*.pkl")
    label_path = _find_file(ad_root, ["AD_Test_AnomalyLabel.pkl", "XJTU-SPS%20for%20AD_Test_AnomalyLabel.pkl"], "*AnomalyLabel*.pkl")

    if not train_path.exists():
        raise FileNotFoundError(f"AD Train file not found under {ad_root}")
    if not test_path.exists():
        raise FileNotFoundError(f"AD Test file not found under {ad_root}")

    train_df = pd.read_pickle(train_path)
    train_df["label"] = 0  # AD_Train is normal-only by convention

    test_df = pd.read_pickle(test_path)
    if label_path.exists():
        labels = pd.read_pickle(label_path)
        if isinstance(labels, pd.DataFrame):
            if "AnomalyLabel" in labels.columns:
                test_df["label"] = labels["AnomalyLabel"].values
            elif "label" in labels.columns:
                test_df["label"] = labels["label"].values
            elif labels.shape[1] == 1:
                test_df["label"] = labels.iloc[:, 0].values
            else:
                test_df["label"] = labels.iloc[:, -1].values
        elif isinstance(labels, pd.Series):
            test_df["label"] = labels.values
        else:
            test_df["label"] = labels.values if hasattr(labels, "values") else labels
    else:
        print(f"[WARN] {label_path.name} not found — test_df has no label column yet.")

    print(f"[AD] train_df: {train_df.shape}, test_df: {test_df.shape}")
    return train_df, test_df


# ---------------------------------------------------------------------------
# FD LOADER — DiagnosisAgent
# ---------------------------------------------------------------------------
def load_fd_data(fd_root: Path = FD_ROOT, class_map: dict = FD_CLASS_MAP):
    """
    Walks each class folder under fd_root, loads *_Train.pkl and
    *_Test.pkl, tags each row with its integer class label.
    Returns: train_df, test_df (both with a 'label' column, 0-17)
    """
    train_frames = []
    test_frames = []

    for class_name, label in class_map.items():
        class_dir = fd_root / class_name
        if not class_dir.exists():
            # Try finding directory case-insensitively
            matches = [d for d in fd_root.iterdir() if d.is_dir() and d.name.lower() == class_name.lower()]
            if matches:
                class_dir = matches[0]
            else:
                print(f"[WARN] folder not found, skipping: {class_dir}")
                continue

        train_files = list(class_dir.glob("*Train*.pkl"))
        test_files = list(class_dir.glob("*Test*.pkl"))

        if train_files:
            df = pd.read_pickle(train_files[0])
            df["label"] = label
            df["class_name"] = class_name
            train_frames.append(df)
        else:
            print(f"[WARN] missing Train pickle in: {class_dir}")

        if test_files:
            df = pd.read_pickle(test_files[0])
            df["label"] = label
            df["class_name"] = class_name
            test_frames.append(df)
        else:
            print(f"[WARN] missing Test pickle in: {class_dir}")

    train_df = pd.concat(train_frames, ignore_index=True) if train_frames else pd.DataFrame()
    test_df = pd.concat(test_frames, ignore_index=True) if test_frames else pd.DataFrame()

    print(f"[FD] train_df: {train_df.shape}, test_df: {test_df.shape}")
    if not train_df.empty:
        print(f"[FD] class distribution (train):\n{train_df['label'].value_counts().sort_index()}")

    return train_df, test_df


# ---------------------------------------------------------------------------
# QUICK SANITY CHECK
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    print("=" * 60)
    print("Loading AD data...")
    ad_train, ad_test = load_ad_data()
    print(ad_train.head())

    print("=" * 60)
    print("Loading FD data...")
    fd_train, fd_test = load_fd_data()
    print(fd_train.head())