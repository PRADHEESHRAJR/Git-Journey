/**
 * AEGIS-SAT: Autonomous Satellite Telemetry & Multi-Agent Diagnosis Engine
 * Fully interactive client-side mission operations center with optional backend API bridging.
 */

// ============================================================================
// 1. DATASETS & STATIC REGISTRIES
// ============================================================================

const SENSOR_COLUMNS = [
  "U_SA", "I_SA", "P_SA",
  "U_Load_output", "I_Load_output", "P_Load_output",
  "U_BCR", "I_BCR", "P_BCR",
  "U_BAT2", "I_BAT2", "T_BAT2",
  "U_BAT3", "I_BAT3", "T_BAT3",
  "U_BAT4", "I_BAT4", "T_BAT4",
  "U_Bus", "I_Bus", "P_Bus",
  "U_Load1", "I_Load1", "T_Load1", "P_Load1",
  "U_Load2", "I_Load2", "T_Load2", "P_Load2",
  "U_Load3", "I_Load3", "T_Load3", "P_Load3",
];

const FD_CLASSES = [
  "Normal",
  "SA_partial component or branch open circuit",
  "SA_partial component or branch short circuit",
  "SA_component deterioration",
  "BCR_open circuit",
  "BCR_short circuit",
  "BCR_increased power loss",
  "BAT_degradation",
  "BAT_open circuit",
  "Bus_open circuit",
  "Bus_short circuit",
  "Bus_insulation breakdown",
  "PDM1_open circuit or short circuit",
  "PDM2_open circuit or short circuit",
  "PDM3_open circuit or short circuit",
  "Load1_open circuit",
  "Load2_open circuit",
  "Load3_open circuit",
];

const FAULT_SEVERITY_TABLE = {
  "Normal": 0.05,
  "Load1_open circuit": 0.20,
  "Load2_open circuit": 0.20,
  "Load3_open circuit": 0.20,
  "SA_component deterioration": 0.25,
  "BAT_degradation": 0.30,
  "SA_partial component or branch open circuit": 0.35,
  "SA_partial component or branch short circuit": 0.50,
  "Bus_insulation breakdown": 0.55,
  "BCR_increased power loss": 0.55,
  "PDM1_open circuit or short circuit": 0.60,
  "PDM2_open circuit or short circuit": 0.60,
  "PDM3_open circuit or short circuit": 0.60,
  "BCR_open circuit": 0.65,
  "BAT_open circuit": 0.85,
  "BCR_short circuit": 0.90,
  "Bus_open circuit": 0.95,
  "Bus_short circuit": 1.00,
};

const SOP_CATALOG = [
  {
    sop_id: "SOP-00-NOMINAL",
    class_name: "Normal",
    subsystem: "EPS / General",
    title: "Nominal On-Orbit Telemetry Housekeeping",
    default_risk: "LOW",
    reversible: true,
    steps: [
      "Maintain standard 1 Hz housekeeping polling cycle.",
      "Verify bus voltage stability within 28V +/- 0.5V margin.",
      "Log rolling baseline statistics for trend analysis."
    ],
    safety_constraints: "None. Normal operations."
  },
  {
    sop_id: "SOP-01-SA-OPEN",
    class_name: "SA_partial component or branch open circuit",
    subsystem: "Solar Array (SA)",
    title: "Solar Array Branch Open Circuit Contingency",
    default_risk: "LOW",
    reversible: true,
    steps: [
      "Command sequential shunt regulator (S3R) to rebalance remaining functional solar array strings.",
      "Trim solar array drive assembly (SADA) gimbal angle by +1.5 deg to optimize incident solar flux.",
      "Update battery charging schedule to accommodate reduced solar current margin."
    ],
    safety_constraints: "Ensure total generation covers vital bus loads with at least 15% safety margin."
  },
  {
    sop_id: "SOP-02-SA-SHORT",
    class_name: "SA_partial component or branch short circuit",
    subsystem: "Solar Array (SA)",
    title: "Solar Array Branch Short Circuit Isolation",
    default_risk: "MEDIUM",
    reversible: true,
    steps: [
      "Actuate string isolation solid-state switch to disconnect shorted panel segment.",
      "Check reverse blocking diodes for thermal runaway or reverse current leak.",
      "Verify bus voltage recovery and monitor temperature gradient across wing panel."
    ],
    safety_constraints: "Prevent thermal overheating on adjacent photovoltaic cells due to reverse bias dissipation."
  },
  {
    sop_id: "SOP-03-SA-DETERIORATE",
    class_name: "SA_component deterioration",
    subsystem: "Solar Array (SA)",
    title: "Solar Array Progressive Deterioration Management",
    default_risk: "LOW",
    reversible: true,
    steps: [
      "Re-tune Maximum Power Point Tracking (MPPT) voltage setpoint curve.",
      "Schedule non-critical payload operations strictly during orbital solar peak.",
      "Recalculate mission end-of-life (EOL) power budget models."
    ],
    safety_constraints: "Do not exceed maximum allowable battery depth-of-discharge (DOD) during eclipse."
  },
  {
    sop_id: "SOP-04-BCR-OPEN",
    class_name: "BCR_open circuit",
    subsystem: "Battery Charge Regulator (BCR)",
    title: "Battery Charge Regulator Open Circuit Switchover",
    default_risk: "MEDIUM",
    reversible: true,
    steps: [
      "Inhibit primary BCR PWM gate drive commands.",
      "Engage redundant secondary BCR module (Channel B) via cross-strap command.",
      "Gradually ramp charge current to verified safe rate (0.2C) and verify battery voltage ramp."
    ],
    safety_constraints: "Confirm secondary BCR telemetry is healthy before commanding full charging current."
  },
  {
    sop_id: "SOP-05-BCR-SHORT",
    class_name: "BCR_short circuit",
    subsystem: "Battery Charge Regulator (BCR)",
    title: "Emergency BCR Short Circuit Isolation",
    default_risk: "HIGH",
    reversible: false,
    steps: [
      "Trigger high-speed latching current limiter (LCL) to isolate shorted BCR input stage.",
      "Switch battery management to emergency unregulated trickle charge bypass mode.",
      "Shed secondary non-essential instruments to preserve bus power equilibrium.",
      "Perform thermal imaging telemetry assessment of EPS power bay."
    ],
    safety_constraints: "Irreversible pyrotechnic / latch isolation may be required if LCL fails to open. High risk of bus collapse."
  },
  {
    sop_id: "SOP-06-BCR-LOSS",
    class_name: "BCR_increased power loss",
    subsystem: "Battery Charge Regulator (BCR)",
    title: "BCR Thermal Dissipation & Power Loss Mitigation",
    default_risk: "MEDIUM",
    reversible: true,
    steps: [
      "Derate BCR charging current limit by 30% to constrain thermal dissipation.",
      "Turn on active loop heat pipe or auxiliary radiator louvers.",
      "Monitor power loss coefficient (P_in - P_out) every 10 seconds."
    ],
    safety_constraints: "Ensure battery temperature remains below 35 deg C operational threshold."
  },
  {
    sop_id: "SOP-07-BAT-DEGRADATION",
    class_name: "BAT_degradation",
    subsystem: "Battery Storage (BAT)",
    title: "Battery Capacity Degradation & Cell Reconditioning",
    default_risk: "LOW",
    reversible: true,
    steps: [
      "Lower End-of-Charge Voltage (EOCV) threshold by 0.15V to reduce cell stress.",
      "Reconfigure battery cell balancing circuit to equalize state-of-charge (SOC).",
      "Restrict payload duty cycle during umbra / eclipse passes to limit maximum DOD to < 35%."
    ],
    safety_constraints: "Prevent cell voltage divergence greater than 25mV across battery blocks."
  },
  {
    sop_id: "SOP-08-BAT-OPEN",
    class_name: "BAT_open circuit",
    subsystem: "Battery Storage (BAT)",
    title: "Battery Open Circuit / String Failure Isolation",
    default_risk: "HIGH",
    reversible: false,
    steps: [
      "Isolate open battery branch via commanded solid-state power controller.",
      "Rebalance remaining parallel battery packs (BAT3, BAT4) to accept eclipse load share.",
      "Declare spacecraft Power Alert Level 2 and transition high-power payloads to standby."
    ],
    safety_constraints: "Significant reduction in total eclipse energy reserve. Requires human ground intervention."
  },
  {
    sop_id: "SOP-09-BUS-OPEN",
    class_name: "Bus_open circuit",
    subsystem: "Main Power Bus",
    title: "Main Power Bus Open Circuit Section Reconfiguration",
    default_risk: "HIGH",
    reversible: true,
    steps: [
      "Command closure of primary cross-tie bus contactor switches.",
      "Reroute downstream distribution modules to secondary redundant power bus ring.",
      "Verify bus impedance telemetry and telemetry return paths."
    ],
    safety_constraints: "Critical spacecraft infrastructure fault. Must verify cross-tie switch ratings."
  },
  {
    sop_id: "SOP-10-BUS-SHORT",
    class_name: "Bus_short circuit",
    subsystem: "Main Power Bus",
    title: "Catastrophic Bus Short Circuit Emergency Isolation",
    default_risk: "HIGH",
    reversible: false,
    steps: [
      "Autonomous hardware fast-trip disconnect of all non-essential load distribution lines.",
      "Isolate suspect bus segment via pyrotechnic / solid-state bus sectionalizing breaker.",
      "Force spacecraft On-Board Computer (OBC) into Safe Survival Mode.",
      "Maintain solar array Sun-pointing orientation for survival power generation."
    ],
    safety_constraints: "Extreme mission threat. Action is irreversible and immediately impacts all payload operations."
  },
  {
    sop_id: "SOP-11-BUS-INSULATION",
    class_name: "Bus_insulation breakdown",
    subsystem: "Main Power Bus",
    title: "Bus Insulation Breakdown & Ground Leakage Containment",
    default_risk: "MEDIUM",
    reversible: true,
    steps: [
      "Activate ground-fault detection circuit to pinpoint chassis leakage path.",
      "Isolate floating ground reference and activate isolated DC-DC converter supply.",
      "Monitor isolation resistance trend to verify degradation stabilization (> 1 MOhm)."
    ],
    safety_constraints: "Prevent electrostatic discharge (ESD) triggering secondary component breakdown."
  },
  {
    sop_id: "SOP-12-PDM1-FAULT",
    class_name: "PDM1_open circuit or short circuit",
    subsystem: "Power Distribution (PDM1)",
    title: "PDM1 Module Fault Recovery & Load Reassignment",
    default_risk: "MEDIUM",
    reversible: true,
    steps: [
      "Trip Solid-State Power Controller (SSPC) channels associated with PDM1 output bus.",
      "Transfer PDM1 essential attitude control loads to PDM2 backup distribution channel.",
      "Perform built-in test (BIT) on PDM1 switch matrix."
    ],
    safety_constraints: "Ensure PDM2 does not exceed maximum continuous thermal current rating."
  },
  {
    sop_id: "SOP-13-PDM2-FAULT",
    class_name: "PDM2_open circuit or short circuit",
    subsystem: "Power Distribution (PDM2)",
    title: "PDM2 Module Fault Recovery & Load Reassignment",
    default_risk: "MEDIUM",
    reversible: true,
    steps: [
      "Trip SSPC channels feeding PDM2 sub-bus.",
      "Cross-strap essential telemetry and communication transmitters to PDM3.",
      "Verify communications link margin with ground tracking station."
    ],
    safety_constraints: "Verify communication transponder prime power remains uninterrupted."
  },
  {
    sop_id: "SOP-14-PDM3-FAULT",
    class_name: "PDM3_open circuit or short circuit",
    subsystem: "Power Distribution (PDM3)",
    title: "PDM3 Module Fault Recovery & Auxiliary Routing",
    default_risk: "MEDIUM",
    reversible: true,
    steps: [
      "De-energize PDM3 branch switches.",
      "Reroute thermal survival heaters to primary bus direct connection.",
      "Confirm payload thermal stabilization above minimum survival temperatures."
    ],
    safety_constraints: "Do not allow thermal control loops to fall below survival limits in shadow."
  },
  {
    sop_id: "SOP-15-LOAD1-OPEN",
    class_name: "Load1_open circuit",
    subsystem: "Payload / Subsystem Load 1",
    title: "Payload Load 1 Open Circuit Diagnostic & Power Cycle",
    default_risk: "LOW",
    reversible: true,
    steps: [
      "Record last-state telemetry from Load 1 interface controller.",
      "Cycle power switch for Load 1 branch (Wait 30s before re-engagement).",
      "If current remains zero, switch to redundant Payload Instrument B."
    ],
    safety_constraints: "Low mission risk; impacts single scientific instrument channel."
  },
  {
    sop_id: "SOP-16-LOAD2-OPEN",
    class_name: "Load2_open circuit",
    subsystem: "Payload / Subsystem Load 2",
    title: "Payload Load 2 Open Circuit Investigation",
    default_risk: "LOW",
    reversible: true,
    steps: [
      "Verify Load 2 driver relay status register.",
      "Command power reset sequence to clear latch-up or open condition.",
      "Activate secondary sensor suite if primary line does not draw nominal power."
    ],
    safety_constraints: "Confirm payload safe-mode state prior to power cycling."
  },
  {
    sop_id: "SOP-17-LOAD3-OPEN",
    class_name: "Load3_open circuit",
    subsystem: "Payload / Subsystem Load 3",
    title: "Payload Load 3 Open Circuit Safe Recovery",
    default_risk: "LOW",
    reversible: true,
    steps: [
      "Poll Load 3 serial interface for internal microcontroller watchdog trip.",
      "Toggle solid-state driver channel.",
      "Switch auxiliary thermal heater off for inactive load to balance total bus draw."
    ],
    safety_constraints: "Routine instrument-level isolation."
  }
];

// ============================================================================
// 2. STATE STORE & APP INITIALIZATION
// ============================================================================

const AppState = {
  activeTab: "tab-dashboard",
  currentScenario: "Normal",
  severityMultiplier: 1.0,
  noiseFloor: 0.30,
  escalationThreshold: 0.58,
  autoencoderThreshold: 0.0280,
  backendConnected: false,
  backendUrl: "http://localhost:8000",
  pipelineRunning: false,
  streamPaused: false,
  
  // Stream Source & Rate
  streamSource: "synthetic", // 'synthetic' | 'dataset' | 'csv'
  streamRateMultiplier: 1,
  streamTimer: null,
  datasetFrameIndex: 0,
  uploadedCsvFrames: null,
  uploadedCsvIndex: 0,
  currentTimeStep: 0,

  // Real-time telemetry buffer (60 points per channel)
  telemetryHistory: {
    U_Bus: [],
    I_Bus: [],
    P_SA: [],
    T_BAT2: [],
    I_Load1: [],
  },

  // 33-sensor live packet
  currentPacket: {},
  
  // Latest diagnosis artifact
  currentResult: null,
};

// Start application on DOM ready
document.addEventListener("DOMContentLoaded", () => {
  initClocks();
  initTabNavigation();
  initCustomClassSelect();
  initTelemetryBuffers();
  initTelemetryCanvas();
  initStreamController();
  initSparklines();
  initSchematicInteractivity();
  initScenarioButtons();
  initSOPKnowledgeBase();
  initFlightDirectorControls();
  checkBackendConnection();

  // Initial nominal run
  triggerMultiAgentPipeline("Normal");

  // Telemetry stream interval (1.0 Hz update by default)
  startStreamTimer();
});

// ============================================================================
// 3. MISSION CLOCKS & NAVIGATION
// ============================================================================

function initClocks() {
  const utcEl = document.getElementById("clock-utc");
  const metEl = document.getElementById("clock-met");
  let metSeconds = 48 * 3600 + 19 * 60 + 22;

  setInterval(() => {
    const now = new Date();
    utcEl.textContent = now.toISOString().substring(11, 19) + " UTC";

    metSeconds++;
    const days = Math.floor(metSeconds / 86400);
    const hrs = Math.floor((metSeconds % 86400) / 3600);
    const mins = Math.floor((metSeconds % 3600) / 60);
    const secs = metSeconds % 60;
    metEl.textContent = `MET +${String(days).padStart(3, '0')}:${String(hrs).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  }, 1000);
}

function initTabNavigation() {
  const tabs = document.querySelectorAll(".tab-btn");
  tabs.forEach(btn => {
    btn.addEventListener("click", () => {
      tabs.forEach(t => t.classList.remove("active"));
      btn.classList.add("active");

      const targetTab = btn.getAttribute("data-tab");
      document.querySelectorAll(".tab-content").forEach(content => {
        content.classList.remove("active");
      });
      const activeContent = document.getElementById(targetTab);
      if (activeContent) {
        activeContent.classList.add("active");
        AppState.activeTab = targetTab;
      }
    });
  });
}

function initCustomClassSelect() {
  const sel = document.getElementById("sel-custom-class");
  if (!sel) return;
  sel.innerHTML = "";
  FD_CLASSES.forEach(cls => {
    const opt = document.createElement("option");
    opt.value = cls;
    opt.textContent = cls;
    sel.appendChild(opt);
  });

  sel.addEventListener("change", (e) => {
    updateAffectedPreview(e.target.value);
  });

  const sliderSev = document.getElementById("slider-severity");
  const lblSev = document.getElementById("lbl-severity-val");
  sliderSev.addEventListener("input", (e) => {
    AppState.severityMultiplier = parseFloat(e.target.value);
    lblSev.textContent = `${AppState.severityMultiplier.toFixed(1)}x`;
  });

  const sliderNoise = document.getElementById("slider-noise");
  const lblNoise = document.getElementById("lbl-noise-val");
  sliderNoise.addEventListener("input", (e) => {
    AppState.noiseFloor = parseFloat(e.target.value);
    lblNoise.textContent = `${AppState.noiseFloor.toFixed(2)} sigma`;
  });

  document.getElementById("btn-inject-and-run").addEventListener("click", () => {
    const selected = sel.value;
    triggerMultiAgentPipeline(selected);
  });

  document.getElementById("btn-reset-nominal").addEventListener("click", () => {
    sel.value = "Normal";
    triggerMultiAgentPipeline("Normal");
  });
}

function updateAffectedPreview(className) {
  const box = document.getElementById("affected-preview-box");
  if (!box) return;
  box.innerHTML = "";

  const affected = getAffectedSensorsForClass(className);
  if (affected.length === 0) {
    box.innerHTML = `<span class="badge-mini status-good">All 33 Channels Normal</span>`;
  } else {
    affected.forEach(ch => {
      const sp = document.createElement("span");
      sp.className = "badge-mini status-alert";
      sp.textContent = ch;
      box.appendChild(sp);
    });
  }
}

function getAffectedSensorsForClass(className) {
  if (className === "Normal") return [];
  if (className.includes("SA")) return ["U_SA", "I_SA", "P_SA", "U_Bus"];
  if (className.includes("BCR")) return ["U_BCR", "I_BCR", "P_BCR", "U_Bus", "I_Bus"];
  if (className.includes("BAT")) return ["U_BAT2", "I_BAT2", "T_BAT2", "U_BAT3", "U_BAT4"];
  if (className.includes("Bus")) return ["U_Bus", "I_Bus", "P_Bus", "U_Load_output"];
  if (className.includes("PDM1")) return ["U_Load1", "I_Load1", "P_Load1"];
  if (className.includes("PDM2")) return ["U_Load2", "I_Load2", "P_Load2"];
  if (className.includes("PDM3")) return ["U_Load3", "I_Load3", "P_Load3"];
  if (className.includes("Load1")) return ["U_Load1", "I_Load1", "P_Load1"];
  if (className.includes("Load2")) return ["U_Load2", "I_Load2", "P_Load2"];
  if (className.includes("Load3")) return ["U_Load3", "I_Load3", "P_Load3"];
  return ["U_Bus", "I_Bus"];
}

// ============================================================================
// 4. TELEMETRY STREAM & CANVAS VISUALIZATION
// ============================================================================

function initTelemetryBuffers() {
  const N = 60;
  for (let i = 0; i < N; i++) {
    AppState.telemetryHistory.U_Bus.push(28.0 + (Math.random() - 0.5) * 0.1);
    AppState.telemetryHistory.I_Bus.push(18.4 + (Math.random() - 0.5) * 0.3);
    AppState.telemetryHistory.P_SA.push(1420 + (Math.random() - 0.5) * 15);
    AppState.telemetryHistory.T_BAT2.push(21.4 + (Math.random() - 0.5) * 0.05);
    AppState.telemetryHistory.I_Load1.push(4.2 + (Math.random() - 0.5) * 0.1);
  }
}

function startStreamTimer() {
  if (AppState.streamTimer) clearInterval(AppState.streamTimer);
  const interval = Math.max(50, Math.floor(1000 / AppState.streamRateMultiplier));
  AppState.streamTimer = setInterval(streamTelemetryStep, interval);
}

function initStreamController() {
  const selSource = document.getElementById("sel-stream-source");
  const fileInput = document.getElementById("input-csv-upload");
  const btnUpload = document.getElementById("btn-trigger-upload");
  const btnStep = document.getElementById("btn-step-frame");
  const btnRawToggle = document.getElementById("btn-toggle-raw-packet");
  const rawDrawer = document.getElementById("raw-packet-drawer");

  selSource?.addEventListener("change", (e) => {
    AppState.streamSource = e.target.value;
    if (AppState.streamSource === "csv") {
      btnUpload.style.display = "inline-flex";
    } else {
      btnUpload.style.display = "none";
    }
  });

  btnUpload?.addEventListener("click", () => fileInput?.click());
  fileInput?.addEventListener("change", handleCsvUpload);

  // Speed Rate Buttons
  const speedBtns = document.querySelectorAll(".btn-speed");
  speedBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      speedBtns.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      AppState.streamRateMultiplier = parseInt(btn.dataset.speed, 10);
      startStreamTimer();
    });
  });

  btnStep?.addEventListener("click", () => {
    streamTelemetryStep(true);
  });

  btnRawToggle?.addEventListener("click", () => {
    const isHidden = rawDrawer.style.display === "none";
    rawDrawer.style.display = isHidden ? "block" : "none";
    btnRawToggle.textContent = isHidden ? "Hide Raw Packet" : "Inspect Raw Telemetry Packet";
    if (isHidden) updateRawPacketGrid();
  });
}

function handleCsvUpload(e) {
  const file = e.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = function(evt) {
    const text = evt.target.result;
    const lines = text.trim().split(/\r?\n/);
    if (lines.length < 2) {
      alert("CSV file has insufficient rows.");
      return;
    }
    const headers = lines[0].split(",").map(h => h.trim());
    const frames = [];

    for (let i = 1; i < lines.length; i++) {
      const parts = lines[i].split(",").map(p => parseFloat(p.trim()));
      if (parts.length === headers.length) {
        const rowObj = {};
        headers.forEach((h, idx) => {
          rowObj[h] = parts[idx];
        });
        frames.push(rowObj);
      }
    }

    if (frames.length > 0) {
      AppState.uploadedCsvFrames = frames;
      AppState.uploadedCsvIndex = 0;
      AppState.streamSource = "csv";
      document.getElementById("sel-stream-source").value = "csv";
      alert(`Loaded ${frames.length} real telemetry rows from '${file.name}'. Streaming live!`);
    }
  };
  reader.readAsText(file);
}

// Pre-extracted sequence of real XJTU-SPS telemetry frames
const REAL_XJTU_SPS_SAMPLES = [
  { U_SA: 24.3, I_SA: 2.46, P_SA: 59.9, U_BCR: 16.69, I_BCR: 3.02, P_BCR: 50.5, U_BAT2: 16.65, I_BAT2: -0.63, T_BAT2: 28.7, U_Bus: 28.02, I_Bus: 18.4, P_Bus: 515.6, U_Load1: 12.11, I_Load1: 4.2, T_Load1: 30.5 },
  { U_SA: 24.4, I_SA: 2.44, P_SA: 59.8, U_BCR: 16.73, I_BCR: 3.37, P_BCR: 56.4, U_BAT2: 16.67, I_BAT2: -0.66, T_BAT2: 28.7, U_Bus: 28.04, I_Bus: 18.5, P_Bus: 518.7, U_Load1: 12.11, I_Load1: 4.2, T_Load1: 30.5 },
  { U_SA: 24.3, I_SA: 2.46, P_SA: 59.9, U_BCR: 16.73, I_BCR: 3.37, P_BCR: 56.5, U_BAT2: 16.67, I_BAT2: -0.66, T_BAT2: 28.7, U_Bus: 28.01, I_Bus: 18.3, P_Bus: 512.5, U_Load1: 12.11, I_Load1: 4.1, T_Load1: 30.5 },
  { U_SA: 24.1, I_SA: 2.47, P_SA: 59.9, U_BCR: 16.74, I_BCR: 3.37, P_BCR: 56.4, U_BAT2: 16.68, I_BAT2: -0.66, T_BAT2: 28.7, U_Bus: 27.99, I_Bus: 18.4, P_Bus: 515.0, U_Load1: 12.11, I_Load1: 4.2, T_Load1: 30.5 },
  { U_SA: 24.3, I_SA: 2.46, P_SA: 59.9, U_BCR: 16.74, I_BCR: 3.37, P_BCR: 56.5, U_BAT2: 16.68, I_BAT2: -0.66, T_BAT2: 28.7, U_Bus: 28.03, I_Bus: 18.4, P_Bus: 515.7, U_Load1: 12.11, I_Load1: 4.2, T_Load1: 30.5 },
  { U_SA: 24.2, I_SA: 2.47, P_SA: 59.8, U_BCR: 16.75, I_BCR: 3.37, P_BCR: 56.4, U_BAT2: 16.69, I_BAT2: -0.66, T_BAT2: 28.7, U_Bus: 28.00, I_Bus: 18.3, P_Bus: 512.4, U_Load1: 12.11, I_Load1: 4.2, T_Load1: 30.5 },
  { U_SA: 24.3, I_SA: 2.46, P_SA: 59.9, U_BCR: 16.75, I_BCR: 3.37, P_BCR: 56.5, U_BAT2: 16.69, I_BAT2: -0.66, T_BAT2: 28.7, U_Bus: 28.02, I_Bus: 18.5, P_Bus: 518.3, U_Load1: 12.11, I_Load1: 4.2, T_Load1: 30.5 },
];

function streamTelemetryStep(forceStep = false) {
  if (AppState.streamPaused && !forceStep) return;

  AppState.currentTimeStep++;
  const scen = AppState.currentScenario;
  const isAnom = scen !== "Normal";
  const sev = AppState.severityMultiplier;
  const noise = AppState.noiseFloor;

  let busV = 28.02;
  let busI = 18.4;
  let saP = 1420;
  let batT = 21.4;
  let l1I = 4.2;

  // Decide source
  if (AppState.streamSource === "csv" && AppState.uploadedCsvFrames && AppState.uploadedCsvFrames.length > 0) {
    const row = AppState.uploadedCsvFrames[AppState.uploadedCsvIndex % AppState.uploadedCsvFrames.length];
    AppState.uploadedCsvIndex++;
    busV = row.U_Bus || row.u_bus || 28.0;
    busI = row.I_Bus || row.i_bus || 18.4;
    saP = row.P_SA || row.p_sa || 1420;
    batT = row.T_BAT2 || row.t_bat2 || 21.4;
    l1I = row.I_Load1 || row.i_load1 || 4.2;
    // Map packet
    SENSOR_COLUMNS.forEach(c => {
      AppState.currentPacket[c] = row[c] !== undefined ? row[c] : (28.0 + Math.random() * 0.1);
    });
  } else if (AppState.streamSource === "dataset") {
    const idx = AppState.datasetFrameIndex % REAL_XJTU_SPS_SAMPLES.length;
    AppState.datasetFrameIndex++;
    const frame = REAL_XJTU_SPS_SAMPLES[idx];
    busV = frame.U_Bus + (Math.random() - 0.5) * 0.05;
    busI = frame.I_Bus + (Math.random() - 0.5) * 0.1;
    saP = frame.P_SA * 23.7; // scale to spacecraft bus
    batT = frame.T_BAT2;
    l1I = frame.I_Load1;
    SENSOR_COLUMNS.forEach(c => {
      AppState.currentPacket[c] = frame[c] !== undefined ? frame[c] : 28.0;
    });
  } else {
    // Mode: Live Orbital Synthesizer
    busV = 28.02 + (Math.random() - 0.5) * 0.08 * (1 + noise);
    busI = 18.4 + (Math.random() - 0.5) * 0.25 * (1 + noise);
    saP = 1420 + (Math.random() - 0.5) * 12 * (1 + noise);
    batT = 21.4 + (Math.random() - 0.5) * 0.04;
    l1I = 4.2 + (Math.random() - 0.5) * 0.08;

    if (isAnom) {
      if (scen.includes("Bus_short")) {
        busV -= 6.5 * sev;
        busI += 12.0 * sev;
      } else if (scen.includes("Bus_open")) {
        busV -= 3.0 * sev;
        busI -= 8.0 * sev;
      } else if (scen.includes("SA")) {
        saP -= 450 * sev;
        busV -= 0.6 * sev;
      } else if (scen.includes("BCR")) {
        busV -= 1.8 * sev;
        busI += 4.5 * sev;
      } else if (scen.includes("BAT_degradation")) {
        batT += 8.5 * sev;
        busV -= 0.8 * sev;
      } else if (scen.includes("BAT_open")) {
        batT += 4.0 * sev;
        busV -= 1.5 * sev;
      } else if (scen.includes("Load1")) {
        l1I = 0.0;
        busI -= 4.2 * sev;
      }
    }

    // Populate all 33 channels
    SENSOR_COLUMNS.forEach(col => {
      if (col.startsWith("U_Bus")) AppState.currentPacket[col] = busV;
      else if (col.startsWith("I_Bus")) AppState.currentPacket[col] = busI;
      else if (col.startsWith("P_Bus")) AppState.currentPacket[col] = busV * busI;
      else if (col.startsWith("P_SA")) AppState.currentPacket[col] = saP;
      else if (col.startsWith("T_BAT")) AppState.currentPacket[col] = batT;
      else if (col.startsWith("I_Load1")) AppState.currentPacket[col] = l1I;
      else AppState.currentPacket[col] = (Math.random() * 2 + 10).toFixed(2);
    });
  }

  // Push to history
  pushVal(AppState.telemetryHistory.U_Bus, busV);
  pushVal(AppState.telemetryHistory.I_Bus, busI);
  pushVal(AppState.telemetryHistory.P_SA, saP);
  pushVal(AppState.telemetryHistory.T_BAT2, batT);
  pushVal(AppState.telemetryHistory.I_Load1, l1I);

  // Update Window metadata text
  const winInfo = document.getElementById("stream-window-info");
  if (winInfo) {
    winInfo.textContent = `T = ${AppState.currentTimeStep}s (60 pts × 33 channels) | Source: ${AppState.streamSource.toUpperCase()}`;
  }

  // Update UI KPI Cards
  document.getElementById("kpi-val-bus").innerHTML = `${busV.toFixed(2)} <span class="kpi-unit">V</span>`;
  document.getElementById("quick-bus-volts").textContent = `${busV.toFixed(2)} V`;
  document.getElementById("kpi-bus-curr").textContent = `${busI.toFixed(1)} A`;
  document.getElementById("kpi-bus-pow").textContent = `${(busV * busI).toFixed(1)} W`;

  document.getElementById("kpi-val-sa").innerHTML = `${Math.round(saP)} <span class="kpi-unit">W</span>`;
  document.getElementById("quick-solar-power").textContent = `${Math.round(saP)} W`;

  document.getElementById("kpi-bat-temp").textContent = `${batT.toFixed(1)} °C`;

  // Draw chart
  drawTelemetryCanvas();
  drawSparklines();

  // Update raw packet drawer if open
  const rawDrawer = document.getElementById("raw-packet-drawer");
  if (rawDrawer && rawDrawer.style.display !== "none") {
    updateRawPacketGrid();
  }
}

function updateRawPacketGrid() {
  const grid = document.getElementById("raw-packet-grid");
  if (!grid) return;
  grid.innerHTML = "";
  SENSOR_COLUMNS.forEach(col => {
    const val = AppState.currentPacket[col] !== undefined ? Number(AppState.currentPacket[col]).toFixed(3) : "—";
    const item = document.createElement("div");
    item.className = "packet-item";
    item.innerHTML = `<span class="packet-name">${col}:</span> <span class="packet-val mono-val">${val}</span>`;
    grid.appendChild(item);
  });
}

function pushVal(arr, val) {
  arr.push(val);
  if (arr.length > 60) arr.shift();
}

function initTelemetryCanvas() {
  const canvas = document.getElementById("live-telemetry-canvas");
  if (!canvas) return;

  const freezeChk = document.getElementById("chk-stream-freeze");
  if (freezeChk) {
    freezeChk.addEventListener("change", (e) => {
      AppState.streamPaused = e.target.checked;
    });
  }

  // Channel toggling pills
  const pills = document.querySelectorAll(".channel-pill");
  pills.forEach(pill => {
    pill.addEventListener("click", () => {
      pill.classList.toggle("active");
      drawTelemetryCanvas();
    });
  });

  drawTelemetryCanvas();
}

function drawTelemetryCanvas() {
  const canvas = document.getElementById("live-telemetry-canvas");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  const W = canvas.width;
  const H = canvas.height;

  ctx.clearRect(0, 0, W, H);

  // Background Grid
  ctx.strokeStyle = "rgba(255, 255, 255, 0.05)";
  ctx.lineWidth = 1;
  const gridX = 10;
  const gridY = 6;
  for (let i = 0; i <= gridX; i++) {
    const x = (W / gridX) * i;
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, H);
    ctx.stroke();
  }
  for (let j = 0; j <= gridY; j++) {
    const y = (H / gridY) * j;
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(W, y);
    ctx.stroke();
  }

  // Draw 28V Nominal Reference Envelope Band
  const nominalY = H * 0.5;
  ctx.fillStyle = "rgba(0, 240, 255, 0.04)";
  ctx.fillRect(0, nominalY - 24, W, 48);
  ctx.strokeStyle = "rgba(0, 240, 255, 0.2)";
  ctx.setLineDash([4, 4]);
  ctx.beginPath();
  ctx.moveTo(0, nominalY);
  ctx.lineTo(W, nominalY);
  ctx.stroke();
  ctx.setLineDash([]);

  // Active Channels to Plot
  const channelConfigs = [
    { id: "U_Bus", color: "#00f0ff", label: "U_Bus (28V)", min: 20, max: 32 },
    { id: "I_Bus", color: "#f59e0b", label: "I_Bus (A)", min: 0, max: 35 },
    { id: "P_SA", color: "#10b981", label: "P_SA (W)", min: 500, max: 1800 },
    { id: "T_BAT2", color: "#ef4444", label: "T_BAT2 (°C)", min: 15, max: 40 },
    { id: "I_Load1", color: "#8b5cf6", label: "I_Load1 (A)", min: 0, max: 10 },
  ];

  const activePills = Array.from(document.querySelectorAll(".channel-pill.active")).map(p => p.dataset.channel);

  channelConfigs.forEach(cfg => {
    if (!activePills.includes(cfg.id)) return;
    const data = AppState.telemetryHistory[cfg.id] || [];
    if (data.length < 2) return;

    ctx.strokeStyle = cfg.color;
    ctx.lineWidth = 2;
    ctx.beginPath();

    data.forEach((val, idx) => {
      const x = (idx / (data.length - 1)) * (W - 20) + 10;
      const normalized = Math.max(0, Math.min(1, (val - cfg.min) / (cfg.max - cfg.min)));
      const y = H - (normalized * (H - 30) + 15);

      if (idx === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });

    ctx.stroke();

    // Pulse dot at the latest sample point
    const lastVal = data[data.length - 1];
    const lastNorm = Math.max(0, Math.min(1, (lastVal - cfg.min) / (cfg.max - cfg.min)));
    const lastX = W - 10;
    const lastY = H - (lastNorm * (H - 30) + 15);

    ctx.fillStyle = cfg.color;
    ctx.beginPath();
    ctx.arc(lastX, lastY, 4, 0, Math.PI * 2);
    ctx.fill();
  });
}

function initSparklines() {
  drawSparklines();
}

function drawSparklines() {
  drawSingleSparkline("kpi-spark-bus", AppState.telemetryHistory.U_Bus, "#00f0ff", 22, 32);
  drawSingleSparkline("kpi-spark-sa", AppState.telemetryHistory.P_SA, "#f59e0b", 800, 1600);
  drawSingleSparkline("kpi-spark-bat", AppState.telemetryHistory.T_BAT2, "#10b981", 18, 30);
  drawSingleSparkline("kpi-spark-load", AppState.telemetryHistory.I_Load1, "#8b5cf6", 0, 8);
}

function drawSingleSparkline(canvasId, data, color, min, max) {
  const canvas = document.getElementById(canvasId);
  if (!canvas || !data || data.length < 2) return;
  const ctx = canvas.getContext("2d");
  const W = canvas.width;
  const H = canvas.height;

  ctx.clearRect(0, 0, W, H);
  ctx.strokeStyle = color;
  ctx.lineWidth = 1.5;
  ctx.beginPath();

  data.slice(-20).forEach((val, idx, slice) => {
    const x = (idx / (slice.length - 1)) * W;
    const norm = Math.max(0, Math.min(1, (val - min) / (max - min)));
    const y = H - (norm * (H - 6) + 3);
    if (idx === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  });
  ctx.stroke();
}

// ============================================================================
// 5. INTERACTIVE ELECTRICAL SCHEMATIC
// ============================================================================

function initSchematicInteractivity() {
  const nodes = document.querySelectorAll(".schematic-node");
  const inspector = document.getElementById("schematic-inspector");

  const descriptions = {
    "node-sa": "Solar Array Wings (Dual Sun-Tracking Panels): Generates 1420W nominal power at 48V DC. Monitored via U_SA, I_SA, P_SA.",
    "node-s3r": "Sequential Shunt Regulator (S3R) & MPPT: Dumps excess solar current during high insolation to protect the 28V bus.",
    "node-bcr": "Battery Charge Regulator (BCR): Controls step-down DC/DC battery charging curves and trickle float states.",
    "node-bat": "Battery System (3 parallel Li-Ion packs: BAT2, BAT3, BAT4): Supplies power during eclipse umbra passes. Monitored via U, I, and Temp sensors.",
    "node-bus": "Main 28V Regulated Power Bus: Spacecraft central power distribution backbone. Regulated to 28.0V ± 0.5V.",
    "node-pdm1": "Power Distribution Module 1 (PDM1): Feeds ADCS attitude control, momentum wheels, and star trackers.",
    "node-pdm2": "Power Distribution Module 2 (PDM2): Supplies S-Band transceiver, command decoders, and On-Board Computer.",
    "node-pdm3": "Power Distribution Module 3 (PDM3): Controls spacecraft survival thermal heaters and radiator loop heat pipes.",
    "node-load1": "Payload Load 1: High-resolution Earth observation science imager instrument.",
    "node-load2": "Payload Load 2: High-gain X-band science data downlink transmitter.",
    "node-load3": "Payload Load 3: Space environmental spectrometer payload package.",
  };

  nodes.forEach(node => {
    node.addEventListener("mouseenter", () => {
      const info = descriptions[node.id] || "Spacecraft EPS subsystem node.";
      if (inspector) inspector.innerHTML = `<b>${node.id.replace('node-', '').toUpperCase()} Node:</b> ${info}`;
    });

    node.addEventListener("click", () => {
      // Toggle fault highlight on click for demonstration
      node.classList.toggle("fault");
    });
  });

  const resetBtn = document.getElementById("btn-reset-schematic");
  if (resetBtn) {
    resetBtn.addEventListener("click", () => {
      document.querySelectorAll(".schematic-node").forEach(n => n.classList.remove("fault"));
      if (inspector) inspector.innerHTML = `<span class="inspector-hint">💡 Hover or click any subsystem block above to inspect detailed sensor parameters and live fault attribution.</span>`;
    });
  }
}

function highlightSchematicFault(scenario) {
  document.querySelectorAll(".schematic-node").forEach(n => n.classList.remove("fault"));

  if (scenario === "Normal") return;

  if (scenario.includes("SA")) {
    document.getElementById("node-sa")?.classList.add("fault");
    document.getElementById("node-s3r")?.classList.add("fault");
  } else if (scenario.includes("BCR")) {
    document.getElementById("node-bcr")?.classList.add("fault");
  } else if (scenario.includes("BAT")) {
    document.getElementById("node-bat")?.classList.add("fault");
  } else if (scenario.includes("Bus")) {
    document.getElementById("node-bus")?.classList.add("fault");
  } else if (scenario.includes("PDM1") || scenario.includes("Load1")) {
    document.getElementById("node-pdm1")?.classList.add("fault");
    document.getElementById("node-load1")?.classList.add("fault");
  } else if (scenario.includes("PDM2") || scenario.includes("Load2")) {
    document.getElementById("node-pdm2")?.classList.add("fault");
    document.getElementById("node-load2")?.classList.add("fault");
  } else if (scenario.includes("PDM3") || scenario.includes("Load3")) {
    document.getElementById("node-pdm3")?.classList.add("fault");
    document.getElementById("node-load3")?.classList.add("fault");
  }
}

// ============================================================================
// 6. MULTI-AGENT PIPELINE DISPATCHER & SIMULATION ENGINE
// ============================================================================

function initScenarioButtons() {
  const cards = document.querySelectorAll(".scenario-card");
  cards.forEach(c => {
    c.addEventListener("click", () => {
      cards.forEach(x => x.classList.remove("active"));
      c.classList.add("active");
      const scen = c.getAttribute("data-scenario");
      triggerMultiAgentPipeline(scen);
    });
  });

  document.getElementById("btn-quick-run-pipeline")?.addEventListener("click", () => {
    // Switch to pipeline tab and run
    document.getElementById("tab-btn-pipeline")?.click();
    triggerMultiAgentPipeline(AppState.currentScenario);
  });

  document.getElementById("btn-retrigger-pipeline")?.addEventListener("click", () => {
    triggerMultiAgentPipeline(AppState.currentScenario);
  });

  document.getElementById("btn-copy-audit")?.addEventListener("click", () => {
    if (AppState.currentResult) {
      navigator.clipboard.writeText(JSON.stringify(AppState.currentResult, null, 2))
        .then(() => alert("Audit trail JSON copied to clipboard!"))
        .catch(() => alert("Failed to copy JSON."));
    }
  });
}

async function triggerMultiAgentPipeline(scenario = "Normal") {
  AppState.currentScenario = scenario;
  highlightSchematicFault(scenario);

  const badgeAgent = document.getElementById("badge-agent-status");
  if (badgeAgent) badgeAgent.textContent = "Running...";

  // Animate flow nodes
  const flowNodes = [
    document.getElementById("flow-node-1"),
    document.getElementById("flow-node-2"),
    document.getElementById("flow-node-3"),
    document.getElementById("flow-node-4")
  ];

  flowNodes.forEach(fn => fn?.classList.remove("active"));
  flowNodes[0]?.classList.add("active");

  const startTime = performance.now();
  let result = null;

  // Attempt to call backend if connected
  if (AppState.backendConnected) {
    try {
      const resp = await fetch(`${AppState.backendUrl}/api/diagnose`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          window_id: `WIN_${Date.now()}`,
          scenario: scenario,
        })
      });
      if (resp.ok) {
        result = await resp.json();
      }
    } catch (err) {
      console.warn("Backend error, falling back to local reasoning engine:", err);
    }
  }

  // Local deterministic fallback reasoning engine (matches Python implementation 1:1)
  if (!result) {
    result = runLocalReasoningEngine(scenario);
  }

  const elapsed = (performance.now() - startTime).toFixed(2);
  result.processing_time_ms = result.processing_time_ms || parseFloat(elapsed);

  // Stagger flow node illumination
  setTimeout(() => flowNodes[1]?.classList.add("active"), 120);
  setTimeout(() => flowNodes[2]?.classList.add("active"), 240);
  setTimeout(() => {
    flowNodes[3]?.classList.add("active");
    if (badgeAgent) badgeAgent.textContent = "Done";
  }, 360);

  // Render pipeline artifacts to UI
  renderPipelineResults(result);
  AppState.currentResult = result;
}

function runLocalReasoningEngine(scenario) {
  const isNominal = scenario === "Normal";
  const winId = `WIN_${new Date().toISOString().substring(11, 19).replace(/:/g, '')}_${isNominal ? 'NOM' : 'FLT'}`;
  const sev = FAULT_SEVERITY_TABLE[scenario] || 0.50;

  // 1. MonitorAgent Anomaly Reconstruction Calculation
  const score = isNominal ? 0.0076 : (0.0280 * (1.2 + sev * 1.8 * AppState.severityMultiplier));
  const isAnomaly = score > AppState.autoencoderThreshold;
  const confidence = isNominal ? 0.994 : Math.min(0.99, 0.75 + sev * 0.22);
  const affectedSensors = getAffectedSensorsForClass(scenario);

  // 2. DiagnosisAgent Alternatives & Hypotheses
  const alternatives = [];
  if (!isNominal) {
    if (scenario.includes("short")) {
      alternatives.push({ class: scenario.replace("short", "open"), probability: 0.04 });
      alternatives.push({ class: "Bus_insulation breakdown", probability: 0.02 });
    } else {
      alternatives.push({ class: "SA_component deterioration", probability: 0.05 });
      alternatives.push({ class: "BCR_increased power loss", probability: 0.02 });
    }
  } else {
    alternatives.push({ class: "Load1_open circuit", probability: 0.004 });
    alternatives.push({ class: "SA_component deterioration", probability: 0.002 });
  }

  // 3. RecoveryPlanner SOP Retrieval (from embedded knowledge base)
  let sop = SOP_CATALOG.find(s => s.class_name.toLowerCase() === scenario.toLowerCase());
  if (!sop) sop = SOP_CATALOG[0];

  // 4. PolicyGate Calibration Formula
  // Composite Risk = 0.50 * Severity + 0.30 * Irreversibility + 0.20 * Uncertainty
  const irrevPenalty = sop.reversible ? 0.0 : 0.85;
  const uncertPenalty = Math.max(0.0, 1.0 - confidence);
  const compositeRisk = Math.min(1.0, Math.max(0.0, (0.50 * sev) + (0.30 * irrevPenalty) + (0.20 * uncertPenalty)));

  const decision = compositeRisk >= AppState.escalationThreshold ? "ESCALATE_TO_FLIGHT_DIRECTOR" : "EXECUTE_AUTONOMOUSLY";

  return {
    window_id: winId,
    timestamp: new Date().toISOString(),
    status: "COMPLETED",
    processing_time_ms: 0.23,
    monitor_report: {
      is_anomaly: isAnomaly,
      anomaly_score: score,
      threshold: AppState.autoencoderThreshold,
      confidence: confidence,
      affected_sensors: affectedSensors,
      rationale: isAnomaly
        ? `Reconstruction error (${score.toFixed(4)}) exceeded calibrated limit (${AppState.autoencoderThreshold.toFixed(4)}) by ${(score / AppState.autoencoderThreshold).toFixed(2)}x. Significant deviations detected in telemetry channels [${affectedSensors.join(', ')}].`
        : `Reconstruction error (${score.toFixed(4)}) remains nominal below operational threshold (${AppState.autoencoderThreshold.toFixed(4)}). Variance is consistent with background thermal noise.`
    },
    diagnosis_report: {
      predicted_class: scenario,
      confidence: confidence,
      top_alternative_classes: alternatives,
      reasoning: isNominal
        ? "Temporal multi-channel correlation indicates baseline equilibrium across all 33 power subsystem telemetry features. No open or short circuit signatures detected."
        : `Temporal feature signature matches ${scenario}. Severe cross-channel covariance observed across [${affectedSensors.slice(0, 3).join(', ')}] consistent with electrical fault pattern.`
    },
    recovery_plan: {
      sop_id: sop.sop_id,
      recommended_action: sop.title,
      action_steps: sop.steps,
      risk_level: sop.default_risk,
      is_reversible: sop.reversible,
      safety_constraints: sop.safety_constraints,
    },
    policy_decision: {
      decision: decision,
      risk_score: compositeRisk,
      requires_human_approval: decision === "ESCALATE_TO_FLIGHT_DIRECTOR",
      risk_factors: {
        fault_severity: sev,
        action_irreversibility: irrevPenalty,
        uncertainty_penalty: uncertPenalty
      },
      governance_rationale: decision === "EXECUTE_AUTONOMOUSLY"
        ? `Autonomous execution permitted. Composite risk score (${compositeRisk.toFixed(2)}) is below the calibrated threshold (${AppState.escalationThreshold.toFixed(2)}).`
        : `Composite risk score (${compositeRisk.toFixed(2)}) exceeds escalation threshold (${AppState.escalationThreshold.toFixed(2)}). Action requires flight director ground authorization.`
    },
    execution_trail: [
      `Pipeline initialized for Window ID: ${winId}`,
      `MonitorAgent: Reconstruction MSE calculated (${score.toFixed(4)}) vs threshold (${AppState.autoencoderThreshold.toFixed(4)}).`,
      `DiagnosisAgent: Diagnosed as '${scenario}' with ${(confidence * 100).toFixed(1)}% confidence.`,
      `RecoveryPlannerAgent: Retrieved & tailored SOP '${sop.sop_id}' (${sop.title}).`,
      `PolicyGate: Gate decision reached -> ${decision}. Risk Index: ${compositeRisk.toFixed(2)}.`
    ]
  };
}

function renderPipelineResults(result) {
  const mon = result.monitor_report;
  const diag = result.diagnosis_report;
  const rec = result.recovery_plan;
  const gate = result.policy_decision;

  // Window metadata tags
  document.getElementById("pipe-win-id").textContent = result.window_id;
  document.getElementById("pipe-latency").textContent = `${result.processing_time_ms} ms`;

  // 1. MonitorAgent
  const a1ScoreVal = document.getElementById("agent1-score-val");
  const a1ScoreBar = document.getElementById("agent1-score-bar");
  const a1Ratio = document.getElementById("agent1-ratio");
  const a1Pill = document.getElementById("agent1-status-pill");
  const a1Rationale = document.getElementById("agent1-rationale");
  const a1DevList = document.getElementById("agent1-deviations");

  a1ScoreVal.textContent = mon.anomaly_score.toFixed(4);
  const ratio = mon.anomaly_score / mon.threshold;
  a1Ratio.textContent = `${ratio.toFixed(2)}x`;
  const barPercent = Math.min(100, (mon.anomaly_score / (mon.threshold * 2.5)) * 100);
  a1ScoreBar.style.width = `${barPercent}%`;

  if (mon.is_anomaly) {
    a1ScoreBar.className = "progress-bar-fill fill-red";
    a1Pill.className = "agent-status-pill status-pill-alert";
    a1Pill.textContent = "ANOMALY DETECTED";
  } else {
    a1ScoreBar.className = "progress-bar-fill fill-green";
    a1Pill.className = "agent-status-pill status-pill-pass";
    a1Pill.textContent = "NOMINAL";
  }
  a1Rationale.textContent = mon.rationale;

  // Dev list
  a1DevList.innerHTML = "";
  if (mon.affected_sensors.length === 0) {
    a1DevList.innerHTML = `<div class="dev-item text-muted">No anomalous deviations detected across telemetry channels.</div>`;
  } else {
    mon.affected_sensors.slice(0, 4).forEach((sensor, idx) => {
      const devVal = (0.015 * (4 - idx) * AppState.severityMultiplier).toFixed(4);
      const width = Math.min(100, 30 + idx * 20);
      const row = document.createElement("div");
      row.className = "dev-item";
      row.innerHTML = `
        <span class="dev-name">${sensor}</span>
        <div class="dev-bar-wrap"><div class="dev-bar" style="width: ${width}%; background: #ef4444;"></div></div>
        <span class="dev-val mono-val">${devVal}</span>
      `;
      a1DevList.appendChild(row);
    });
  }

  // 2. DiagnosisAgent
  document.getElementById("agent2-predicted-class").textContent = diag.predicted_class;
  document.getElementById("agent2-confidence").textContent = `Confidence: ${(diag.confidence * 100).toFixed(1)}%`;
  document.getElementById("agent2-reasoning").textContent = diag.reasoning;

  const altList = document.getElementById("agent2-alternatives");
  altList.innerHTML = "";
  (diag.top_alternative_classes || []).forEach(alt => {
    const probPct = (alt.probability * 100).toFixed(1);
    const item = document.createElement("div");
    item.className = "alt-item";
    item.innerHTML = `
      <div class="alt-info">
        <span class="alt-name">${alt.class}</span>
        <span class="alt-prob mono-val">${probPct}%</span>
      </div>
      <div class="alt-bar-wrap"><div class="alt-bar" style="width: ${Math.max(2, alt.probability * 100 * 2)}%;"></div></div>
    `;
    altList.appendChild(item);
  });

  // 3. RecoveryPlannerAgent
  document.getElementById("agent3-sop-id").textContent = rec.sop_id;
  document.getElementById("agent3-sop-title").textContent = rec.recommended_action;
  
  const riskTag = document.getElementById("agent3-risk-tag");
  riskTag.textContent = `${rec.risk_level} RISK`;
  riskTag.className = `badge-mini badge-risk-${rec.risk_level.toLowerCase()}`;

  const revTag = document.getElementById("agent3-rev-tag");
  revTag.textContent = rec.is_reversible ? "REVERSIBLE" : "IRREVERSIBLE";
  revTag.className = `badge-mini ${rec.is_reversible ? 'badge-rev' : 'badge-irrev'}`;

  const stepsList = document.getElementById("agent3-steps-list");
  stepsList.innerHTML = "";
  (rec.action_steps || []).forEach(step => {
    const li = document.createElement("li");
    li.innerHTML = `<label><input type="checkbox" checked> ${step}</label>`;
    stepsList.appendChild(li);
  });

  document.getElementById("agent3-safety").textContent = rec.safety_constraints;

  // 4. PolicyGateAgent
  const gateCode = document.getElementById("agent4-decision-code");
  const gateScore = document.getElementById("agent4-risk-score");
  const gateBar = document.getElementById("agent4-risk-bar");
  const gatePill = document.getElementById("agent4-status-pill");
  const gateRationale = document.getElementById("agent4-rationale");

  gateCode.textContent = gate.decision;
  gateScore.textContent = `${gate.risk_score.toFixed(2)} / 1.00`;
  gateBar.style.width = `${gate.risk_score * 100}%`;

  if (gate.decision === "EXECUTE_AUTONOMOUSLY") {
    gateCode.className = "decision-code text-green";
    gateBar.className = "progress-bar-fill fill-green";
    gatePill.className = "agent-status-pill status-pill-pass";
    gatePill.textContent = "APPROVED";
  } else {
    gateCode.className = "decision-code text-red";
    gateBar.className = "progress-bar-fill fill-red";
    gatePill.className = "agent-status-pill status-pill-alert";
    gatePill.textContent = "ESCALATED";
  }

  document.getElementById("agent4-factor-sev").textContent = gate.risk_factors.fault_severity.toFixed(2);
  document.getElementById("agent4-factor-irrev").textContent = gate.risk_factors.action_irreversibility.toFixed(2);
  document.getElementById("agent4-factor-uncert").textContent = gate.risk_factors.uncertainty_penalty.toFixed(2);
  gateRationale.textContent = gate.governance_rationale;

  // Audit Trail Box
  const auditBox = document.getElementById("audit-log-body");
  auditBox.innerHTML = "";
  (result.execution_trail || []).forEach(step => {
    const d = document.createElement("div");
    d.className = "log-line";
    d.innerHTML = `<span class="log-ts">[${new Date().toTimeString().substring(0, 8)}]</span> ${step}`;
    auditBox.appendChild(d);
  });

  // Update Flight Director Console View
  updateFlightDirectorView(result);

  // Update Alert Summary Banner on Dashboard
  updateDashboardAlertBanner(result);
}

function updateDashboardAlertBanner(result) {
  const banner = document.getElementById("alert-summary-bar");
  const title = document.getElementById("alert-summary-title");
  const badge = document.getElementById("alert-summary-badge");
  const desc = document.getElementById("alert-summary-desc");
  const icon = document.getElementById("alert-icon-box");
  const healthPill = document.getElementById("quick-overall-health");
  const gateAlertBadge = document.getElementById("badge-gate-alert");

  if (!banner) return;

  const isAnom = result.monitor_report.is_anomaly;
  const isEscalate = result.policy_decision.requires_human_approval;

  if (isAnom) {
    banner.classList.add("alert");
    title.textContent = `CRITICAL ALERT: ${result.diagnosis_report.predicted_class.toUpperCase()}`;
    badge.className = "alert-tag badge-tag-alert";
    badge.textContent = `RECONSTRUCTION MSE: ${result.monitor_report.anomaly_score.toFixed(4)} (THRESHOLD: ${AppState.autoencoderThreshold.toFixed(4)})`;
    desc.textContent = `${result.policy_decision.decision} — SOP: ${result.recovery_plan.sop_id}. ${result.recovery_plan.recommended_action}`;
    icon.innerHTML = `<svg viewBox="0 0 24 24" width="24" height="24" stroke="#ef4444" fill="none" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>`;

    healthPill.textContent = "ANOMALY";
    healthPill.className = "pill-value badge-health alert";

    if (gateAlertBadge) gateAlertBadge.style.display = isEscalate ? "inline-block" : "none";
  } else {
    banner.classList.remove("alert");
    title.textContent = "Telemetry Status: NOMINAL ON-ORBIT OPERATION";
    badge.className = "alert-tag badge-tag-good";
    badge.textContent = `AUTOENCODER RECONSTRUCTION ERROR: ${result.monitor_report.anomaly_score.toFixed(4)} (BELOW THRESHOLD ${AppState.autoencoderThreshold.toFixed(4)})`;
    desc.textContent = "All 33 spacecraft electrical telemetry channels within 2-sigma operational bounds. Continuous background monitoring active at 1.0 Hz.";
    icon.innerHTML = `<svg viewBox="0 0 24 24" width="24" height="24" stroke="#10b981" fill="none" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/></svg>`;

    healthPill.textContent = "NOMINAL";
    healthPill.className = "pill-value badge-health";

    if (gateAlertBadge) gateAlertBadge.style.display = "none";
  }
}

// ============================================================================
// 7. FLIGHT DIRECTOR POLICY GATE CONSOLE
// ============================================================================

function initFlightDirectorControls() {
  const sliderThresh = document.getElementById("slider-gate-thresh");
  const lblThresh = document.getElementById("lbl-gate-thresh");

  if (sliderThresh) {
    sliderThresh.addEventListener("input", (e) => {
      AppState.escalationThreshold = parseFloat(e.target.value);
      lblThresh.textContent = AppState.escalationThreshold.toFixed(2);
      if (AppState.currentResult) {
        // Recalculate policy gate with updated threshold
        triggerMultiAgentPipeline(AppState.currentScenario);
      }
    });
  }

  const btnAuth = document.getElementById("btn-fd-authorize");
  const btnOverrule = document.getElementById("btn-fd-overrule");
  const btnSafehold = document.getElementById("btn-fd-safehold");
  const logBox = document.getElementById("fd-action-log");

  btnAuth?.addEventListener("click", () => {
    appendFDLog(`[AUTHORIZED] Flight Director manually approved telecommand uplink for ${document.getElementById("pcc-sop").textContent}. Uplink ACK received!`);
    btnAuth.disabled = true;
    btnOverrule.disabled = true;
  });

  btnOverrule?.addEventListener("click", () => {
    appendFDLog(`[OVERRULED] Flight Director rejected automated SOP. Switching to secondary redundant power bus.`);
    btnAuth.disabled = true;
    btnOverrule.disabled = true;
  });

  btnSafehold?.addEventListener("click", () => {
    appendFDLog(`[EMERGENCY SAFEHOLD] Spacecraft commanded into Safe Survival Mode. All non-essential loads shed. SADA Sun-lock engaged.`);
    triggerMultiAgentPipeline("Normal");
  });
}

function appendFDLog(msg) {
  const log = document.getElementById("fd-action-log");
  if (!log) return;
  const line = document.createElement("div");
  line.className = "log-line text-cyan";
  line.innerHTML = `<span class="log-ts">[${new Date().toTimeString().substring(0, 8)}]</span> ${msg}`;
  log.prepend(line);
}

function updateFlightDirectorView(result) {
  const gate = result.policy_decision;
  const rec = result.recovery_plan;

  const heroCard = document.getElementById("fd-hero-card");
  const heroDec = document.getElementById("fd-hero-decision");
  const heroDesc = document.getElementById("fd-hero-desc");
  const heroIcon = document.getElementById("fd-hero-icon");
  const hitlTag = document.getElementById("hitl-tag");
  const hitlInst = document.getElementById("hitl-instructions");

  const btnAuth = document.getElementById("btn-fd-authorize");
  const btnOverrule = document.getElementById("btn-fd-overrule");

  // Factors
  document.getElementById("fd-val-sev").textContent = gate.risk_factors.fault_severity.toFixed(2);
  document.getElementById("fd-bar-sev").style.width = `${gate.risk_factors.fault_severity * 100}%`;

  document.getElementById("fd-val-irrev").textContent = gate.risk_factors.action_irreversibility.toFixed(2);
  document.getElementById("fd-bar-irrev").style.width = `${gate.risk_factors.action_irreversibility * 100}%`;

  document.getElementById("fd-val-uncert").textContent = gate.risk_factors.uncertainty_penalty.toFixed(2);
  document.getElementById("fd-bar-uncert").style.width = `${gate.risk_factors.uncertainty_penalty * 100}%`;

  // Pending card
  document.getElementById("pcc-sop").textContent = rec.sop_id;
  document.getElementById("pcc-risk").textContent = `${rec.risk_level} RISK`;
  document.getElementById("pcc-title").textContent = rec.recommended_action;
  document.getElementById("pcc-steps").textContent = `First Step: ${rec.action_steps[0] || 'Execute commanded sequence.'}`;

  if (gate.requires_human_approval) {
    heroCard.className = "fd-hero-card escalate";
    heroDec.textContent = "ESCALATE_TO_FLIGHT_DIRECTOR";
    heroDec.className = "fd-hero-decision text-red";
    heroDesc.textContent = `High-risk telemetry anomaly (Risk Index: ${gate.risk_score.toFixed(2)} ≥ ${AppState.escalationThreshold.toFixed(2)}). Automated execution blocked by policy governance.`;
    heroIcon.textContent = "🚨";

    hitlTag.textContent = "ACTION REQUIRED — FLIGHT DIRECTOR APPROVAL PENDING";
    hitlTag.className = "hitl-tag alert";
    hitlInst.textContent = `Review recommended procedure ${rec.sop_id} (${rec.recommended_action}). Authorize command execution or force alternate safehold.`;

    btnAuth.disabled = false;
    btnOverrule.disabled = false;
  } else {
    heroCard.className = "fd-hero-card";
    heroDec.textContent = "EXECUTE_AUTONOMOUSLY";
    heroDec.className = "fd-hero-decision text-green";
    heroDesc.textContent = `Risk level (${gate.risk_score.toFixed(2)}) is below escalation limit (${AppState.escalationThreshold.toFixed(2)}). Autonomous spacecraft contingency execution permitted.`;
    heroIcon.textContent = "🛡️";

    hitlTag.textContent = "STANDBY — AUTONOMOUS FLIGHT ENVELOPE ACTIVE";
    hitlTag.className = "hitl-tag";
    hitlInst.textContent = "Autonomous execution enabled. No manual ground intervention required.";

    btnAuth.disabled = true;
    btnOverrule.disabled = true;
  }
}

// ============================================================================
// 8. SOP KNOWLEDGE BASE BROWSER
// ============================================================================

function initSOPKnowledgeBase() {
  const container = document.getElementById("sops-grid-container");
  const searchInput = document.getElementById("input-sop-search");
  const filterChips = document.querySelectorAll(".sop-filter-chips .chip");
  let currentFilter = "all";

  renderSOPGrid(SOP_CATALOG);

  searchInput?.addEventListener("input", (e) => {
    const q = e.target.value.toLowerCase().trim();
    filterSOPs(q, currentFilter);
  });

  filterChips.forEach(chip => {
    chip.addEventListener("click", () => {
      filterChips.forEach(c => c.classList.remove("active"));
      chip.classList.add("active");
      currentFilter = chip.getAttribute("data-filter");
      filterSOPs(searchInput?.value.toLowerCase().trim() || "", currentFilter);
    });
  });

  // Modal setup
  const modal = document.getElementById("sop-modal");
  document.getElementById("btn-close-modal")?.addEventListener("click", () => {
    modal.style.display = "none";
  });
  modal?.addEventListener("click", (e) => {
    if (e.target === modal) modal.style.display = "none";
  });
}

function filterSOPs(query, filter) {
  const filtered = SOP_CATALOG.filter(sop => {
    const matchFilter = (filter === "all") || (sop.subsystem.toLowerCase().includes(filter.toLowerCase()));
    if (!matchFilter) return false;

    if (!query) return true;
    const text = `${sop.sop_id} ${sop.class_name} ${sop.subsystem} ${sop.title} ${sop.steps.join(' ')}`.toLowerCase();
    return text.includes(query);
  });

  renderSOPGrid(filtered);
}

function renderSOPGrid(sops) {
  const container = document.getElementById("sops-grid-container");
  if (!container) return;
  container.innerHTML = "";

  if (sops.length === 0) {
    container.innerHTML = `<div class="text-muted" style="grid-column: 1/-1; text-align: center; padding: 40px;">No Standard Operating Procedures found matching query.</div>`;
    return;
  }

  sops.forEach(sop => {
    const card = document.createElement("div");
    card.className = "sop-card-item";
    card.innerHTML = `
      <div>
        <div class="sop-card-top">
          <span class="sop-card-code text-cyan">${sop.sop_id}</span>
          <span class="badge-mini badge-risk-${sop.default_risk.toLowerCase()}">${sop.default_risk} RISK</span>
        </div>
        <h4 class="sop-card-title">${sop.title}</h4>
        <div class="sop-card-subsystem">Subsystem: ${sop.subsystem}</div>
      </div>
      <div class="sop-card-steps-preview">
        <b>Primary Step:</b> ${sop.steps[0] || 'Standard protocol.'}
      </div>
      <div class="sop-card-bottom">
        <span class="badge-mini ${sop.reversible ? 'badge-rev' : 'badge-irrev'}">${sop.reversible ? 'REVERSIBLE' : 'IRREVERSIBLE'}</span>
        <button class="btn-xs btn-outline btn-view-sop">View Full SOP</button>
      </div>
    `;

    card.querySelector(".btn-view-sop").addEventListener("click", (e) => {
      e.stopPropagation();
      openSOPModal(sop);
    });
    card.addEventListener("click", () => openSOPModal(sop));

    container.appendChild(card);
  });
}

function openSOPModal(sop) {
  const modal = document.getElementById("sop-modal");
  document.getElementById("modal-sop-code").textContent = sop.sop_id;
  document.getElementById("modal-sop-title").textContent = sop.title;

  const body = document.getElementById("modal-sop-body");
  body.innerHTML = `
    <div style="margin-bottom: 16px;">
      <span class="badge-mini badge-risk-${sop.default_risk.toLowerCase()}">${sop.default_risk} RISK</span>
      <span class="badge-mini ${sop.reversible ? 'badge-rev' : 'badge-irrev'}">${sop.reversible ? 'REVERSIBLE' : 'IRREVERSIBLE'}</span>
      <span class="badge-mini" style="margin-left: 8px;">Subsystem: ${sop.subsystem}</span>
    </div>
    <p><b>Target Subsystem Class:</b> <span class="mono-val text-cyan">${sop.class_name}</span></p>
    
    <h4 style="margin: 18px 0 8px; color: #ffffff;">Standard Operating Procedure Steps:</h4>
    <ol style="padding-left: 20px; line-height: 1.8;">
      ${sop.steps.map(s => `<li>${s}</li>`).join('')}
    </ol>

    <h4 style="margin: 18px 0 8px; color: #f59e0b;">Safety Constraints & Hazard Mitigation:</h4>
    <div style="background: rgba(245, 158, 11, 0.1); border-left: 3px solid #f59e0b; padding: 12px; border-radius: 4px;">
      ${sop.safety_constraints}
    </div>

    <div style="margin-top: 24px; display: flex; justify-content: flex-end;">
      <button class="btn btn-primary" onclick="document.getElementById('sop-modal').style.display='none'; triggerMultiAgentPipeline('${sop.class_name}'); document.getElementById('tab-btn-pipeline').click();">
        Test SOP in Multi-Agent Pipeline
      </button>
    </div>
  `;

  modal.style.display = "flex";
}

// ============================================================================
// 9. BACKEND API DETECTOR & HEALTH PROBER
// ============================================================================

async function checkBackendConnection() {
  const dot = document.getElementById("engine-dot");
  const title = document.getElementById("engine-title");
  const sub = document.getElementById("engine-sub");
  const pingBtn = document.getElementById("btn-ping-backend");
  const footerStatus = document.getElementById("footer-engine-status");

  pingBtn?.addEventListener("click", (e) => {
    e.stopPropagation();
    probeBackend();
  });

  document.getElementById("backend-status-card")?.addEventListener("click", probeBackend);

  async function probeBackend() {
    title.textContent = "CHECKING API...";
    sub.textContent = "Pinging localhost:8000...";

    try {
      const res = await fetch(`${AppState.backendUrl}/api/status`, { mode: 'cors' });
      if (res.ok) {
        const data = await res.json();
        AppState.backendConnected = true;
        dot.className = "engine-dot online";
        title.textContent = "LIVE PYTORCH BACKEND";
        sub.textContent = `Connected (${data.backend_type})`;
        if (footerStatus) footerStatus.textContent = `Engine: Live PyTorch Multi-Agent (${data.backend_type})`;
        return;
      }
    } catch (e) {
      // Backend not running
    }

    AppState.backendConnected = false;
    dot.className = "engine-dot";
    title.textContent = "CLIENT SIMULATOR";
    sub.textContent = "Ready (Stand-Alone)";
    if (footerStatus) footerStatus.textContent = "Engine: Stand-Alone Web Simulator (PyTorch Rule-Equivalence)";
  }

  // Initial probe
  probeBackend();
}
