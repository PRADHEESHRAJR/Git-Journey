"""
Preprocessing & Windowing Module — Multi-Agent Satellite Fault Diagnosis
=========================================================================
Implements sliding-window segmentation and feature standardization
fitted strictly on normal/training telemetry.

Adheres to Phase 1 specifications:
- Slices time-series into fixed-length sliding windows (configurable W, S).
- Per-feature normalization fit ONLY on normal/training data.
- Generates reproducible, traceable windows with start/end timestamps.
"""

from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
import joblib

from data_loader import SENSOR_COLUMNS, load_ad_data, load_fd_data, BASE_DIR

PREPROC_DIR = BASE_DIR / "artifacts" / "preprocessing"
PREPROC_DIR.mkdir(parents=True, exist_ok=True)


class TelemetryNormalizer:
    """
    Standardizes sensor telemetry features.
    Fitted ONLY on normal/training data to prevent data leakage.
    """
    def __init__(self, feature_columns: list[str] = SENSOR_COLUMNS):
        self.feature_columns = feature_columns
        self.scaler = StandardScaler()
        self.is_fitted = False

    def fit(self, df: pd.DataFrame) -> "TelemetryNormalizer":
        missing_cols = [c for c in self.feature_columns if c not in df.columns]
        if missing_cols:
            raise ValueError(f"Missing columns in fitting dataframe: {missing_cols}")
        data = df[self.feature_columns].values.astype(np.float32)
        # Handle possible NaN / Inf
        data = np.nan_to_num(data, nan=0.0, posinf=1e6, neginf=-1e6)
        self.scaler.fit(data)
        self.is_fitted = True
        return self

    def transform(self, df: pd.DataFrame) -> pd.DataFrame:
        if not self.is_fitted:
            raise RuntimeError("Normalizer must be fitted before transform.")
        out_df = df.copy()
        data = df[self.feature_columns].values.astype(np.float32)
        data = np.nan_to_num(data, nan=0.0, posinf=1e6, neginf=-1e6)
        out_df[self.feature_columns] = self.scaler.transform(data)
        return out_df

    def transform_array(self, X: np.ndarray) -> np.ndarray:
        """Transforms a 2D or 3D numpy array."""
        if not self.is_fitted:
            raise RuntimeError("Normalizer must be fitted before transform.")
        orig_shape = X.shape
        if len(orig_shape) == 2:
            data = np.nan_to_num(X, nan=0.0, posinf=1e6, neginf=-1e6)
            return self.scaler.transform(data)
        elif len(orig_shape) == 3:
            # (N, W, D) -> (N*W, D) -> (N, W, D)
            N, W, D = orig_shape
            flat = X.reshape(-1, D)
            flat = np.nan_to_num(flat, nan=0.0, posinf=1e6, neginf=-1e6)
            scaled = self.scaler.transform(flat)
            return scaled.reshape(N, W, D)
        else:
            raise ValueError(f"Expected 2D or 3D array, got shape {orig_shape}")

    def save(self, filepath: Path = PREPROC_DIR / "scaler.joblib"):
        filepath = Path(filepath)
        filepath.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump({"scaler": self.scaler, "feature_columns": self.feature_columns}, filepath)
        print(f"[Normalizer] Scaler saved to {filepath}")

    @classmethod
    def load(cls, filepath: Path = PREPROC_DIR / "scaler.joblib") -> "TelemetryNormalizer":
        saved = joblib.load(filepath)
        obj = cls(feature_columns=saved["feature_columns"])
        obj.scaler = saved["scaler"]
        obj.is_fitted = True
        return obj


def create_sliding_windows(
    df: pd.DataFrame,
    window_size: int = 60,
    step_size: int = 30,
    feature_cols: list[str] = SENSOR_COLUMNS,
    label_col: str = "label",
    time_col: str = "Time",
    binary_anomaly: bool = True,
    max_windows: int = None,
) -> tuple[np.ndarray, np.ndarray, list[dict]]:
    """
    Slices a continuous telemetry DataFrame into sliding windows.

    Args:
        df: Input DataFrame containing feature_cols, optionally time_col and label_col.
        window_size: Number of timesteps per window (e.g. 60 or 128).
        step_size: Stride/stride step size between consecutive windows.
        feature_cols: Telemetry sensor column names.
        label_col: Label column name if present.
        time_col: Timestamp column name if present.
        binary_anomaly: For AD, mark window as 1 if ANY timestep is anomalous.
                        For FD (multiclass), assign majority / last class label.
        max_windows: Optional cap for quick testing.

    Returns:
        X: np.ndarray of shape (num_windows, window_size, len(feature_cols))
        y: np.ndarray of shape (num_windows,)
        metadata: list of dicts with window start_time, end_time, index range.
    """
    num_rows = len(df)
    if num_rows < window_size:
        return (
            np.empty((0, window_size, len(feature_cols)), dtype=np.float32),
            np.empty((0,), dtype=np.int64),
            [],
        )

    # Extract numerical features as contiguous array
    features = df[feature_cols].values.astype(np.float32)
    has_labels = label_col in df.columns
    labels = df[label_col].values if has_labels else None
    has_time = time_col in df.columns
    times = df[time_col].values if has_time else None

    # Calculate window indices across time
    all_indices = list(range(0, num_rows - window_size + 1, step_size))
    if max_windows is not None and len(all_indices) > max_windows:
        if has_labels and binary_anomaly and np.any(labels == 1):
            # Capture representative normal and anomalous temporal windows
            anom_indices = []
            norm_indices = []
            for idx in all_indices:
                if np.any(labels[idx : idx + window_size] == 1):
                    anom_indices.append(idx)
                else:
                    norm_indices.append(idx)

            if anom_indices:
                n_anom = min(len(anom_indices), max_windows // 2)
                n_norm = max_windows - n_anom
                step_a = max(1, len(anom_indices) // max(1, n_anom))
                step_n = max(1, len(norm_indices) // max(1, n_norm))
                sel_anom = [anom_indices[i * step_a] for i in range(min(n_anom, len(anom_indices)))]
                sel_norm = [norm_indices[i * step_n] for i in range(min(n_norm, len(norm_indices)))]
                indices = sorted(sel_anom + sel_norm)
            else:
                stride = len(all_indices) / max_windows
                indices = [all_indices[int(i * stride)] for i in range(max_windows)]
        else:
            stride = len(all_indices) / max_windows
            indices = [all_indices[int(i * stride)] for i in range(max_windows)]
    else:
        indices = all_indices

    X_list = []
    y_list = []
    meta_list = []

    for start_idx in indices:
        end_idx = start_idx + window_size
        window_feat = features[start_idx:end_idx]
        X_list.append(window_feat)

        if has_labels:
            window_labels = labels[start_idx:end_idx]
            if binary_anomaly:
                # AD rule: Anomaly if at least one timestamp in window is anomalous
                win_label = 1 if np.any(window_labels == 1) else 0
            else:
                # FD rule: mode / majority label in the window
                vals, counts = np.unique(window_labels, return_counts=True)
                win_label = int(vals[np.argmax(counts)])
            y_list.append(win_label)
        else:
            y_list.append(0)

        meta_list.append({
            "start_idx": start_idx,
            "end_idx": end_idx,
            "start_time": str(times[start_idx]) if has_time else str(start_idx),
            "end_time": str(times[end_idx - 1]) if has_time else str(end_idx - 1),
        })

    X = np.stack(X_list, axis=0) if X_list else np.empty((0, window_size, len(feature_cols)), dtype=np.float32)
    y = np.array(y_list, dtype=np.int64) if y_list else np.empty((0,), dtype=np.int64)

    return X, y, meta_list


def prepare_ad_windows(
    window_size: int = 60,
    train_step: int = 60,
    test_step: int = 30,
    max_train_windows: int = 5000,
    max_test_windows: int = 5000,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, TelemetryNormalizer]:
    """
    End-to-end pipeline for Phase 1 AD:
    1. Loads AD_Train and AD_Test
    2. Fits TelemetryNormalizer on AD_Train (normal-only)
    3. Normalizes AD_Train and AD_Test
    4. Slices into sliding windows
    """
    print("[Pipeline] Loading AD datasets...")
    train_df, test_df = load_ad_data()

    print("[Pipeline] Fitting TelemetryNormalizer on AD_Train normal telemetry...")
    normalizer = TelemetryNormalizer(SENSOR_COLUMNS)
    normalizer.fit(train_df)
    normalizer.save(PREPROC_DIR / "ad_normalizer.joblib")

    print("[Pipeline] Standardizing telemetry features...")
    train_df_norm = normalizer.transform(train_df)
    test_df_norm = normalizer.transform(test_df)

    print(f"[Pipeline] Windowing AD_Train (W={window_size}, S={train_step})...")
    X_train, y_train, _ = create_sliding_windows(
        train_df_norm,
        window_size=window_size,
        step_size=train_step,
        binary_anomaly=True,
        max_windows=max_train_windows,
    )

    print(f"[Pipeline] Windowing AD_Test (W={window_size}, S={test_step})...")
    X_test, y_test, _ = create_sliding_windows(
        test_df_norm,
        window_size=window_size,
        step_size=test_step,
        binary_anomaly=True,
        max_windows=max_test_windows,
    )

    return X_train, y_train, X_test, y_test, normalizer


def prepare_fd_windows(
    window_size: int = 60,
    step_size: int = 30,
    normalizer: TelemetryNormalizer = None,
    max_windows_per_class: int = 400,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, TelemetryNormalizer]:
    """
    End-to-end pipeline for Phase 1 FD:
    1. Loads all 18 classes of FD data
    2. Normalizes using provided or fitted normalizer (fit on Normal class train data)
    3. Slices each class into sliding windows and combines
    """
    print("[Pipeline] Loading FD datasets across all 18 classes...")
    train_df, test_df = load_fd_data()

    if normalizer is None:
        print("[Pipeline] Fitting normalizer on Normal class train telemetry...")
        normal_train = train_df[train_df["label"] == 0]
        if normal_train.empty:
            normal_train = train_df  # Fallback
        normalizer = TelemetryNormalizer(SENSOR_COLUMNS)
        normalizer.fit(normal_train)
        normalizer.save(PREPROC_DIR / "fd_normalizer.joblib")

    train_df_norm = normalizer.transform(train_df)
    test_df_norm = normalizer.transform(test_df)

    # Process class by class to maintain balance
    def window_by_class(df_sub: pd.DataFrame, max_per_class: int):
        all_X = []
        all_y = []
        for class_label in sorted(df_sub["label"].unique()):
            cls_df = df_sub[df_sub["label"] == class_label]
            X_c, y_c, _ = create_sliding_windows(
                cls_df,
                window_size=window_size,
                step_size=step_size,
                binary_anomaly=False,
                max_windows=max_per_class,
            )
            if len(X_c) > 0:
                all_X.append(X_c)
                all_y.append(y_c)
        if not all_X:
            return np.empty((0, window_size, len(SENSOR_COLUMNS))), np.empty((0,), dtype=np.int64)
        return np.concatenate(all_X, axis=0), np.concatenate(all_y, axis=0)

    print(f"[Pipeline] Windowing FD Train data (max {max_windows_per_class}/class)...")
    X_train, y_train = window_by_class(train_df_norm, max_windows_per_class)

    print(f"[Pipeline] Windowing FD Test data (max {max_windows_per_class}/class)...")
    X_test, y_test = window_by_class(test_df_norm, max_windows_per_class)

    return X_train, y_train, X_test, y_test, normalizer


if __name__ == "__main__":
    print("=" * 70)
    print("PHASE 1 VALIDATION: DATA PIPELINE & PREPROCESSING")
    print("=" * 70)

    # 1. AD Pipeline Validation
    print("\n--- 1. Anomaly Detection (AD) Windowing ---")
    X_ad_train, y_ad_train, X_ad_test, y_ad_test, ad_norm = prepare_ad_windows(
        window_size=60,
        train_step=60,
        test_step=60,
        max_train_windows=1000,
        max_test_windows=1000,
    )
    print(f"AD Train Windows: {X_ad_train.shape} | Labels: {y_ad_train.shape} (Anomalies: {np.sum(y_ad_train)})")
    print(f"AD Test Windows:  {X_ad_test.shape} | Labels: {y_ad_test.shape} (Anomalies: {np.sum(y_ad_test)} / {len(y_ad_test)} = {np.mean(y_ad_test)*100:.1f}%)")

    # 2. FD Pipeline Validation
    print("\n--- 2. Fault Diagnosis (FD) Windowing ---")
    X_fd_train, y_fd_train, X_fd_test, y_fd_test, fd_norm = prepare_fd_windows(
        window_size=60,
        step_size=60,
        normalizer=ad_norm,
        max_windows_per_class=100,
    )
    print(f"FD Train Windows: {X_fd_train.shape} | Labels: {y_fd_train.shape}")
    print(f"FD Test Windows:  {X_fd_test.shape} | Labels: {y_fd_test.shape}")
    print(f"FD Classes present in Train: {sorted(np.unique(y_fd_train).tolist())}")
    print(f"FD Classes present in Test:  {sorted(np.unique(y_fd_test).tolist())}")

    # 3. Sample Window Inspection
    print("\n--- 3. Sample Window Inspection ---")
    sample_win = X_ad_train[0]
    print(f"Sample window shape (T x Sensors): {sample_win.shape}")
    print(f"First 3 timesteps of SA sensors (U_SA, I_SA, P_SA):")
    print(sample_win[:3, :3])

    print("\n" + "=" * 70)
    print("PHASE 1 COMPLETED SUCCESSFULLY: Windowing & normalization verified.")
    print("=" * 70)
