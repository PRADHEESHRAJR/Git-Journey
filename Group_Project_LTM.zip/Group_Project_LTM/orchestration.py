"""
Multi-Agent Satellite Fault Diagnosis & Recovery Pipeline Orchestration
========================================================================
Phase 6 Orchestration:
Wires all 4 LLM-based agents into a unified sequential state pipeline.
Implements LangGraph StateGraph with graceful fallback pipeline.

Pipeline Flow:
[Raw Telemetry Window]
       │
       ▼
1. MonitorAgent        ───> (Reconstruction score, affected channels, anomaly report)
       │
       ▼
2. DiagnosisAgent      ───> (18-class root cause, confidence, alternative hypotheses)
       │
       ▼
3. RecoveryPlannerAgent ───> (RAG-retrieved SOP, tailored action steps, reversibility)
       │
       ▼
4. PolicyGateAgent     ───> (Risk calibration, explainable factors, execute vs escalate)
"""

import sys
from typing import TypedDict, Optional, Any, List
from pathlib import Path
import json
import numpy as np
import time

ROOT_DIR = Path(__file__).resolve().parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from agents.monitor_agent import MonitorAgent, MODEL_PATH as MONITOR_MODEL_PATH
from agents.diagnosis_agent import DiagnosisAgent, MODEL_PATH as DIAG_MODEL_PATH
from agents.recovery_planner_agent import RecoveryPlannerAgent
from agents.policy_gate_agent import PolicyGateAgent
from preprocessing import TelemetryNormalizer, PREPROC_DIR
from data_loader import SENSOR_COLUMNS, FD_CLASS_MAP

# ---------------------------------------------------------------------------
# Pipeline State Definition
# ---------------------------------------------------------------------------
class SatelliteState(TypedDict):
    window_id: str
    telemetry_window: Any  # np.ndarray shape (W, D)
    timestamp: str
    # Agent Artifacts
    monitor_report: Optional[dict]
    diagnosis_report: Optional[dict]
    recovery_plan: Optional[dict]
    policy_decision: Optional[dict]
    # Traceability
    execution_trail: List[str]
    processing_time_ms: float
    status: str


# ---------------------------------------------------------------------------
# Multi-Agent Pipeline Coordinator
# ---------------------------------------------------------------------------
class SatelliteMultiAgentSystem:
    def __init__(
        self,
        monitor_agent: Optional[MonitorAgent] = None,
        diagnosis_agent: Optional[DiagnosisAgent] = None,
        recovery_agent: Optional[RecoveryPlannerAgent] = None,
        policy_gate_agent: Optional[PolicyGateAgent] = None,
    ):
        # Initialize normalizer if available
        norm_path = PREPROC_DIR / "ad_normalizer.joblib"
        normalizer = TelemetryNormalizer.load(norm_path) if norm_path.exists() else None

        # 1. MonitorAgent
        if monitor_agent is not None:
            self.monitor = monitor_agent
        else:
            self.monitor = MonitorAgent(normalizer=normalizer)
            if MONITOR_MODEL_PATH.exists():
                self.monitor.load_backbone(MONITOR_MODEL_PATH)

        # 2. DiagnosisAgent
        if diagnosis_agent is not None:
            self.diagnosis = diagnosis_agent
        else:
            self.diagnosis = DiagnosisAgent(normalizer=normalizer)
            if DIAG_MODEL_PATH.exists():
                self.diagnosis.load_backbone(DIAG_MODEL_PATH)

        # 3. RecoveryPlannerAgent
        self.recovery = recovery_agent or RecoveryPlannerAgent()

        # 4. PolicyGateAgent
        self.policy_gate = policy_gate_agent or PolicyGateAgent(escalation_threshold=0.58)

        # Try configuring LangGraph if available
        self._init_graph()

    def _init_graph(self):
        self.use_langgraph = False
        try:
            from langgraph.graph import StateGraph, END
            workflow = StateGraph(SatelliteState)

            # Define graph nodes
            workflow.add_node("monitor_agent", self._monitor_node)
            workflow.add_node("diagnosis_agent", self._diagnosis_node)
            workflow.add_node("recovery_agent", self._recovery_node)
            workflow.add_node("policy_gate", self._policy_gate_node)

            # Set linear pipeline edges
            workflow.set_entry_point("monitor_agent")
            workflow.add_edge("monitor_agent", "diagnosis_agent")
            workflow.add_edge("diagnosis_agent", "recovery_agent")
            workflow.add_edge("recovery_agent", "policy_gate")
            workflow.add_edge("policy_gate", END)

            self.graph = workflow.compile()
            self.use_langgraph = True
            print("[Orchestration] Compiled LangGraph StateGraph successfully.")
        except Exception as e:
            self.use_langgraph = False
            self.graph = None
            print(f"[Orchestration] LangGraph unavailable or skipped ({e}). Using native sequential coordinator.")

    # Node Implementations
    def _monitor_node(self, state: SatelliteState) -> dict:
        window = state["telemetry_window"]
        report = self.monitor.analyze_window(window)
        trail = state.get("execution_trail", []) + ["MonitorAgent: Anomaly score calculated & evaluated."]
        return {"monitor_report": report, "execution_trail": trail}

    def _diagnosis_node(self, state: SatelliteState) -> dict:
        window = state["telemetry_window"]
        affected = state["monitor_report"].get("affected_sensors", []) if state.get("monitor_report") else []
        report = self.diagnosis.diagnose_window(window, affected_sensors=affected)
        trail = state.get("execution_trail", []) + [f"DiagnosisAgent: Diagnosed as '{report.get('predicted_class')}'."]
        return {"diagnosis_report": report, "execution_trail": trail}

    def _recovery_node(self, state: SatelliteState) -> dict:
        diag = state["diagnosis_report"].get("predicted_class", "Normal") if state.get("diagnosis_report") else "Normal"
        conf = state["diagnosis_report"].get("confidence", 1.0) if state.get("diagnosis_report") else 1.0
        affected = state["monitor_report"].get("affected_sensors", []) if state.get("monitor_report") else []
        plan = self.recovery.generate_plan(diag, confidence=conf, affected_sensors=affected)
        trail = state.get("execution_trail", []) + [f"RecoveryPlannerAgent: Retrieved & tailored SOP '{plan.get('sop_id')}'."]
        return {"recovery_plan": plan, "execution_trail": trail}

    def _policy_gate_node(self, state: SatelliteState) -> dict:
        diag = state["diagnosis_report"].get("predicted_class", "Normal") if state.get("diagnosis_report") else "Normal"
        conf = state["diagnosis_report"].get("confidence", 1.0) if state.get("diagnosis_report") else 1.0
        plan = state.get("recovery_plan", {})
        decision = self.policy_gate.evaluate_policy(diag, conf, plan)
        trail = state.get("execution_trail", []) + [f"PolicyGate: Gate decision reached -> {decision.get('decision')}."]
        return {"policy_decision": decision, "execution_trail": trail, "status": "COMPLETED"}

    def run(self, telemetry_window: np.ndarray, window_id: str = "win_001", timestamp: str = "") -> SatelliteState:
        """
        Executes the end-to-end multi-agent pipeline on a single telemetry window.
        Returns the full structured state dictionary with complete intermediate audit trail.
        """
        t0 = time.perf_counter()

        initial_state: SatelliteState = {
            "window_id": window_id,
            "telemetry_window": telemetry_window,
            "timestamp": timestamp or time.strftime("%Y-%m-%d %H:%M:%S"),
            "monitor_report": None,
            "diagnosis_report": None,
            "recovery_plan": None,
            "policy_decision": None,
            "execution_trail": [f"Pipeline initialized for Window ID: {window_id}"],
            "processing_time_ms": 0.0,
            "status": "IN_PROGRESS",
        }

        if self.use_langgraph and self.graph is not None:
            final_state = self.graph.invoke(initial_state)
        else:
            # Sequential pipeline execution
            s1 = self._monitor_node(initial_state)
            initial_state.update(s1)

            s2 = self._diagnosis_node(initial_state)
            initial_state.update(s2)

            s3 = self._recovery_node(initial_state)
            initial_state.update(s3)

            s4 = self._policy_gate_node(initial_state)
            initial_state.update(s4)
            final_state = initial_state

        elapsed_ms = (time.perf_counter() - t0) * 1000
        final_state["processing_time_ms"] = round(elapsed_ms, 2)
        return final_state


if __name__ == "__main__":
    print("=" * 70)
    print("PHASE 6 VALIDATION: MULTI-AGENT PIPELINE ORCHESTRATION")
    print("=" * 70)

    # Synthetic / realistic telemetry window verification
    print("\n--- Initializing Multi-Agent Pipeline System ---")
    system = SatelliteMultiAgentSystem()

    # Generate test window (60 timesteps, 33 sensors)
    # Simulate a nominal window
    np.random.seed(42)
    nominal_window = np.random.normal(loc=0.0, scale=0.5, size=(60, len(SENSOR_COLUMNS))).astype(np.float32)

    # Simulate an anomalous battery / bus short fault window
    fault_window = np.random.normal(loc=0.0, scale=0.5, size=(60, len(SENSOR_COLUMNS))).astype(np.float32)
    # Inject severe voltage sag and high current on bus channels (columns 16, 17, 18)
    fault_window[:, 16] -= 4.5  # U_Bus sag
    fault_window[:, 17] += 5.2  # I_Bus surge

    test_runs = [
        ("WIN_NOMINAL_01", nominal_window, "Nominal Housekeeping Window"),
        ("WIN_FAULT_BUS_02", fault_window, "Bus Fault Shock Window"),
    ]

    for win_id, win_data, desc in test_runs:
        print("\n" + "#" * 60)
        print(f"RUNNING PIPELINE TEST: {desc} ({win_id})")
        print("#" * 60)

        result = system.run(win_data, window_id=win_id)

        print("\n--- 1. MonitorAgent Report ---")
        mon = result["monitor_report"]
        print(f"  Is Anomaly:       {mon.get('is_anomaly')}")
        print(f"  Confidence:       {mon.get('confidence')}")
        print(f"  Affected Sensors: {mon.get('affected_sensors')}")
        print(f"  Rationale:        {mon.get('rationale')}")

        print("\n--- 2. DiagnosisAgent Report ---")
        diag = result["diagnosis_report"]
        print(f"  Predicted Class:  {diag.get('predicted_class')}")
        print(f"  Confidence:       {diag.get('confidence')}")
        print(f"  Top Alternatives: {diag.get('top_alternative_classes')}")
        print(f"  Reasoning:        {diag.get('reasoning')}")

        print("\n--- 3. RecoveryPlannerAgent Report ---")
        rec = result["recovery_plan"]
        print(f"  SOP Assigned:     {rec.get('sop_id')}")
        print(f"  Recommended Plan: {rec.get('recommended_action')}")
        print(f"  Action Steps:     {rec.get('action_steps')}")
        print(f"  Risk Level:       {rec.get('risk_level')}")
        print(f"  Is Reversible:    {rec.get('is_reversible')}")

        print("\n--- 4. PolicyGate Decision (ApprovalAgent) ---")
        gate = result["policy_decision"]
        print(f"  GATING DECISION:  >> {gate.get('decision')} <<")
        print(f"  Risk Score:       {gate.get('risk_score')}")
        print(f"  Human Escalation: {gate.get('requires_human_approval')}")
        print(f"  Risk Factors:     {gate.get('risk_factors')}")
        print(f"  Governance Audit: {gate.get('governance_rationale')}")

        print("\n--- Execution Audit Trail ---")
        for step in result["execution_trail"]:
            print(f"  -> {step}")
        print(f"  Total Pipeline Latency: {result['processing_time_ms']} ms")

    print("\n" + "=" * 70)
    print("PHASE 6 COMPLETED SUCCESSFULLY: End-to-end multi-agent orchestration verified.")
    print("=" * 70)
