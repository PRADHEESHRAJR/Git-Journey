"""
DiagnosisAgent — 18-Class Root-Cause Fault Classification
=========================================================
Phase 3 Agent:
1. Classifies telemetry signatures across 18 satellite subsystem fault classes.
2. Identifies top alternatives (differentiating open vs short circuit failure modes).
3. Invokes LLM reasoning layer to synthesize structured diagnosis report.
"""

import sys
from pathlib import Path
import numpy as np
import json

ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from data_loader import SENSOR_COLUMNS, FD_CLASS_MAP, BASE_DIR
from preprocessing import prepare_fd_windows, TelemetryNormalizer
from models.classifier import TelemetryFaultClassifier
from agents.llm_client import LLMClient

MODEL_PATH = BASE_DIR / "artifacts" / "models" / "diagnosis_classifier.pt"

# Invert FD_CLASS_MAP: integer -> class name
INV_CLASS_MAP = {v: k for k, v in FD_CLASS_MAP.items()}


class DiagnosisAgent:
    def __init__(self, classifier: TelemetryFaultClassifier = None, normalizer: TelemetryNormalizer = None):
        self.classifier = classifier
        self.normalizer = normalizer
        self.llm = LLMClient()
        self.inv_class_map = INV_CLASS_MAP

    def train_backbone(self, X_train: np.ndarray, y_train: np.ndarray, epochs: int = 10, batch_size: int = 64):
        """Trains the underlying deep classifier on 18 fault classes."""
        if self.classifier is None:
            self.classifier = TelemetryFaultClassifier(
                in_features=len(SENSOR_COLUMNS),
                num_classes=18,
            )
        self.classifier.fit(X_train, y_train, epochs=epochs, batch_size=batch_size)
        MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
        self.classifier.save(MODEL_PATH)

    def load_backbone(self, model_path: Path = MODEL_PATH):
        self.classifier = TelemetryFaultClassifier.load(model_path)

    def diagnose_window(self, window: np.ndarray, affected_sensors: list[str] = None) -> dict:
        """
        Diagnoses a single telemetry window of shape (W, D) or (1, W, D).
        Returns a structured LLM root-cause diagnosis report.
        """
        if self.classifier is None:
            raise RuntimeError("DiagnosisAgent backbone classifier is not initialized or trained.")

        if window.ndim == 2:
            X = np.expand_dims(window, axis=0)  # (1, W, D)
        elif window.ndim == 3:
            X = window
        else:
            raise ValueError(f"Expected 2D or 3D window, got shape {window.shape}")

        probs = self.classifier.predict_proba(X)[0]  # (18,)
        sorted_indices = np.argsort(probs)[::-1]

        top_class_id = int(sorted_indices[0])
        top_class_name = self.inv_class_map.get(top_class_id, f"Fault_{top_class_id}")
        confidence = float(probs[top_class_id])

        # Top 3 alternative classes
        alternatives = []
        for idx in sorted_indices[1:4]:
            alt_id = int(idx)
            alt_name = self.inv_class_map.get(alt_id, f"Fault_{alt_id}")
            alternatives.append({
                "class_id": alt_id,
                "class_name": alt_name,
                "prob": round(float(probs[alt_id]), 4),
            })

        affected_sensors = affected_sensors or []

        prompt = (
            f"Satellite Telemetry Diagnosis Agent Analysis:\n"
            f"- Primary Diagnosis: {top_class_name} (Class {top_class_id})\n"
            f"- Model Confidence: {confidence*100:.2f}%\n"
            f"- Top Alternative Hypotheses: {json.dumps(alternatives)}\n"
            f"- Anomaly Indicator Channels: {affected_sensors}\n\n"
            f"Generate a structured JSON diagnosis report with fields: predicted_class (string), "
            f"confidence (0.0-1.0), top_alternative_classes (list), and reasoning (detailed engineering root-cause explanation)."
        )

        report = self.llm.generate(
            prompt=prompt,
            task_type="diagnosis",
            predicted_class=top_class_name,
            confidence=confidence,
            top_alternatives=alternatives,
            affected_sensors=affected_sensors,
        )

        report["class_id"] = top_class_id
        report["all_class_probabilities"] = [round(float(p), 4) for p in probs]
        return report


if __name__ == "__main__":
    print("=" * 70)
    print("PHASE 3 VALIDATION: DIAGNOSIS AGENT (BACKBONE + LLM LAYER)")
    print("=" * 70)

    # 1. Load data
    print("\n--- 1. Preparing Data for DiagnosisAgent ---")
    X_train, y_train, X_test, y_test, normalizer = prepare_fd_windows(
        window_size=60,
        step_size=60,
        max_windows_per_class=120,
    )

    # 2. Train Backbone
    print("\n--- 2. Training Classifier Backbone ---")
    agent = DiagnosisAgent(normalizer=normalizer)
    agent.train_backbone(X_train, y_train, epochs=8, batch_size=64)

    # 3. Quantitative Evaluation
    print("\n--- 3. Quantitative Evaluation on FD_Test ---")
    eval_results = agent.classifier.evaluate(
        X_test, y_test,
        class_names=[INV_CLASS_MAP[i] for i in range(18)]
    )
    print(f"Overall Accuracy: {eval_results['overall_accuracy']*100:.2f}%")
    print("\nSample Class Performance:")
    for c_id in [0, 1, 4, 7, 9]:
        c_name = INV_CLASS_MAP[c_id]
        if c_name in eval_results["classification_report"]:
            metrics = eval_results["classification_report"][c_name]
            print(f"  [{c_id:02d}] {c_name[:35]:35s} | P: {metrics['precision']:.2f}, R: {metrics['recall']:.2f}, F1: {metrics['f1-score']:.2f}")

    # 4. LLM Layer Diagnosis Reports
    print("\n--- 4. LLM Layer Inference on Sample Fault Classes ---")
    for sample_label in [0, 4, 7]:  # Normal, BCR_open, BAT_degradation
        indices = np.where(y_test == sample_label)[0]
        if len(indices) > 0:
            idx = indices[0]
            true_name = INV_CLASS_MAP[sample_label]
            print(f"\n[Test Sample with Ground Truth: {true_name}]")
            diag_report = agent.diagnose_window(X_test[idx], affected_sensors=["U_BAT2", "I_BCR"])
            print(json.dumps(diag_report, indent=2))

    print("\n" + "=" * 70)
    print("PHASE 3 COMPLETED SUCCESSFULLY: DiagnosisAgent trained and verified.")
    print("=" * 70)
