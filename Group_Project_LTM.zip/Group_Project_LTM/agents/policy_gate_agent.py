"""
ApprovalAgent / PolicyGate — Risk-Calibrated Gating & Explainable Governance
=============================================================================
Phase 5 Agent (Core Project Novelty):
1. Computes composite risk index fusing fault severity, action reversibility,
   and model diagnosis confidence.
2. Emits risk-calibrated execution decision (EXECUTE_AUTONOMOUSLY vs ESCALATE_TO_HUMAN).
3. Produces structured, inspectable explainability factors for auditability and patenting.
"""

import sys
from pathlib import Path
from typing import Optional
import json

ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from agents.llm_client import LLMClient

# Subsystem Severity Catalog (0.0 to 1.0)
FAULT_SEVERITY_TABLE = {
    "Normal": 0.05,
    "Load1_open circuit": 0.20,
    "Load2_open circuit": 0.20,
    "Load3_open circuit": 0.20,
    "SA_component deterioration": 0.25,
    "BAT_degradation": 0.30,
    "SA_partial component or branch open circuit": 0.35,
    "SA_partial component or branch short circuit": 0.50,
    "Bus_insulation breakdown": 0.55,
    "BCR_increased power loss": 0.55,
    "PDM1_open circuit or short circuit": 0.60,
    "PDM2_open circuit or short circuit": 0.60,
    "PDM3_open circuit or short circuit": 0.60,
    "BCR_open circuit": 0.65,
    "BAT_open circuit": 0.85,
    "BCR_short circuit": 0.90,
    "Bus_open circuit": 0.95,
    "Bus_short circuit": 1.00,
}


def calculate_risk_index(
    diagnosis: str,
    confidence: float,
    is_reversible: bool,
    risk_level: str = "MEDIUM",
) -> float:
    """
    Computes mathematical composite risk index in range [0.0, 1.0].
    Fuses:
    - Fault Severity (50%)
    - Action Irreversibility Penalty (30%)
    - Model Diagnostic Uncertainty (20%)
    """
    severity = FAULT_SEVERITY_TABLE.get(diagnosis, 0.50)
    
    # Adjust severity based on explicit risk level
    if risk_level.upper() == "HIGH":
        severity = max(severity, 0.80)
    elif risk_level.upper() == "LOW":
        severity = min(severity, 0.30)

    # Irreversibility penalty: irreversible actions carry a high penalty
    irreversibility_penalty = 0.0 if is_reversible else 0.85

    # Uncertainty penalty: lower confidence yields higher risk
    uncertainty_penalty = max(0.0, 1.0 - confidence)

    # Composite formula
    composite = 0.50 * severity + 0.30 * irreversibility_penalty + 0.20 * uncertainty_penalty
    return min(1.0, max(0.0, composite))


class PolicyGateAgent:
    def __init__(self, escalation_threshold: float = 0.58):
        self.escalation_threshold = escalation_threshold
        self.llm = LLMClient()

    def evaluate_policy(
        self,
        diagnosis: str,
        confidence: float,
        recovery_plan: dict,
    ) -> dict:
        """
        Evaluates risk calibration and governance policy for proposed recovery action.
        Returns structured gating decision and explanation.
        """
        risk_level = recovery_plan.get("risk_level", "MEDIUM")
        is_reversible = recovery_plan.get("is_reversible", True)
        sop_id = recovery_plan.get("sop_id", "N/A")

        # 1. Quantitative Risk Scoring
        risk_score = calculate_risk_index(
            diagnosis=diagnosis,
            confidence=confidence,
            is_reversible=is_reversible,
            risk_level=risk_level,
        )

        # 2. Formulate Structured Reasoner Prompt
        prompt = (
            f"Satellite PolicyGate & Approval Agent Evaluation:\n"
            f"- Diagnosed State: {diagnosis} (Model Confidence: {confidence*100:.1f}%)\n"
            f"- Target SOP: {sop_id}\n"
            f"- Action Reversibility: {'REVERSIBLE' if is_reversible else 'IRREVERSIBLE'}\n"
            f"- Declared Risk Level: {risk_level}\n"
            f"- Computed Risk Index: {risk_score:.4f} (Escalation Threshold: {self.escalation_threshold:.2f})\n\n"
            f"Evaluate whether autonomous execution is safe or requires human mission controller approval. "
            f"Generate a structured JSON decision with fields: decision ('EXECUTE_AUTONOMOUSLY' or 'ESCALATE_TO_HUMAN'), "
            f"risk_score (float), risk_factors (list of strings), requires_human_approval (bool), and governance_rationale (string)."
        )

        decision_data = self.llm.generate(
            prompt=prompt,
            task_type="policy",
            risk_score=risk_score,
            diagnosis=diagnosis,
            confidence=confidence,
            risk_level=risk_level,
            is_reversible=is_reversible,
            recovery_plan=recovery_plan,
        )

        # Add explicit safety checklist & audit metadata
        decision_data["severity_score"] = round(FAULT_SEVERITY_TABLE.get(diagnosis, 0.50), 3)
        decision_data["is_reversible"] = is_reversible
        decision_data["confidence"] = round(float(confidence), 4)

        if decision_data["requires_human_approval"]:
            decision_data["safety_checklist"] = [
                "Ground Station Link Verified (S-band/X-band)",
                "Telemetry Confirmation of Subsystem Redundancy",
                "Flight Director Command Authorization Signature",
            ]
        else:
            decision_data["safety_checklist"] = [
                "Pre-execution bus voltage and temperature margin check",
                "Automated rollback snapshot captured",
            ]

        return decision_data


if __name__ == "__main__":
    print("=" * 70)
    print("PHASE 5 VALIDATION: APPROVAL AGENT / POLICY GATE (RISK GATING & EXPLAINABILITY)")
    print("=" * 70)

    gate = PolicyGateAgent(escalation_threshold=0.58)

    test_cases = [
        {
            "desc": "Nominal Operation",
            "diag": "Normal",
            "conf": 0.98,
            "plan": {"risk_level": "LOW", "is_reversible": True, "sop_id": "SOP-00-NOMINAL"}
        },
        {
            "desc": "Routine Reversible Fault (Low Risk)",
            "diag": "SA_component deterioration",
            "conf": 0.92,
            "plan": {"risk_level": "LOW", "is_reversible": True, "sop_id": "SOP-03-SA-DETERIORATE"}
        },
        {
            "desc": "Ambiguous/Low Confidence Fault (Escalate)",
            "diag": "BCR_open circuit",
            "conf": 0.52,
            "plan": {"risk_level": "MEDIUM", "is_reversible": True, "sop_id": "SOP-04-BCR-OPEN"}
        },
        {
            "desc": "Critical Irreversible Fault (Escalate)",
            "diag": "Bus_short circuit",
            "conf": 0.95,
            "plan": {"risk_level": "HIGH", "is_reversible": False, "sop_id": "SOP-10-BUS-SHORT"}
        },
    ]

    for case in test_cases:
        print(f"\n--- Scenario: {case['desc']} ---")
        dec = gate.evaluate_policy(
            diagnosis=case["diag"],
            confidence=case["conf"],
            recovery_plan=case["plan"],
        )
        print(f"Diagnosis:       {case['diag']} (Conf: {case['conf']*100:.1f}%)")
        print(f"Decision:        {dec.get('decision')}")
        print(f"Risk Score:      {dec.get('risk_score')}")
        print(f"Human Approval:  {dec.get('requires_human_approval')}")
        print(f"Risk Factors:    {dec.get('risk_factors')}")
        print(f"Rationale:       {dec.get('governance_rationale')}")

    print("\n" + "=" * 70)
    print("PHASE 5 COMPLETED SUCCESSFULLY: PolicyGate risk calibration verified.")
    print("=" * 70)
