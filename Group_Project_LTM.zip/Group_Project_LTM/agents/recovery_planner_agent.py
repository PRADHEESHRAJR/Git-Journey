"""
RecoveryPlannerAgent — RAG-Grounded Recovery Plan Generation
=============================================================
Phase 4 Agent:
1. Queries SOP knowledge base for standard contingency procedures.
2. Contextualizes procedures with diagnosed fault class and sensor channels.
3. Invokes LLM reasoning layer to generate risk-calibrated, reversible action plans.
"""

import sys
from pathlib import Path
import json

ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from agents.llm_client import LLMClient
from knowledge_base.rag_engine import get_knowledge_base, SOPKnowledgeBase


class RecoveryPlannerAgent:
    def __init__(self, kb: SOPKnowledgeBase = None):
        self.kb = kb or get_knowledge_base()
        self.llm = LLMClient()

    def generate_plan(self, diagnosis: str, confidence: float = 1.0, affected_sensors: list[str] = None) -> dict:
        """
        Retrieves matching SOP and prompts LLM to generate a structured recovery plan.
        """
        affected_sensors = affected_sensors or []
        query = f"{diagnosis} {' '.join(affected_sensors)}"
        retrieved_docs = self.kb.retrieve(query, top_k=1)

        sop_doc = retrieved_docs[0] if retrieved_docs else {
            "sop_id": "SOP-CONTINGENCY-DEFAULT",
            "class_name": diagnosis,
            "title": f"Contingency Response for {diagnosis}",
            "default_risk": "MEDIUM",
            "reversible": True,
            "steps": ["Isolate suspect line", "Verify telemetry stability", "Consult ground team"],
            "safety_constraints": "Standard mission protection guidelines.",
        }

        prompt = (
            f"Satellite Recovery Planner Agent Request:\n"
            f"- Diagnosed Fault: {diagnosis} (Confidence: {confidence*100:.1f}%)\n"
            f"- Affected Telemetry Sensors: {affected_sensors}\n"
            f"- Retrieved Operating Procedure:\n"
            f"  * SOP ID: {sop_doc.get('sop_id')}\n"
            f"  * Title: {sop_doc.get('title')}\n"
            f"  * Default Risk Level: {sop_doc.get('default_risk')}\n"
            f"  * Reversible Action: {sop_doc.get('reversible')}\n"
            f"  * Baseline Steps: {sop_doc.get('steps')}\n"
            f"  * Constraints: {sop_doc.get('safety_constraints')}\n\n"
            f"Generate a tailored JSON recovery plan with fields: diagnosis (string), sop_id (string), "
            f"recommended_action (string), action_steps (list of strings), risk_level ('LOW'|'MEDIUM'|'HIGH'), "
            f"is_reversible (bool), and expected_outcome (string)."
        )

        plan = self.llm.generate(
            prompt=prompt,
            task_type="recovery",
            diagnosis=diagnosis,
            sop_content=sop_doc,
            affected_sensors=affected_sensors,
        )

        plan["retrieved_sop"] = sop_doc
        return plan


if __name__ == "__main__":
    print("=" * 70)
    print("PHASE 4 VALIDATION: RECOVERY PLANNER AGENT (RAG + LLM LAYER)")
    print("=" * 70)

    agent = RecoveryPlannerAgent()

    test_diagnoses = [
        ("Normal", ["U_Bus", "I_Bus"]),
        ("BCR_open circuit", ["U_BCR", "I_BCR"]),
        ("BAT_degradation", ["U_BAT2", "T_BAT2"]),
        ("Bus_short circuit", ["U_Bus", "I_Bus", "P_Bus"]),
    ]

    for diag, sensors in test_diagnoses:
        print(f"\n--- Testing Recovery Plan for: '{diag}' ---")
        plan = agent.generate_plan(diag, confidence=0.92, affected_sensors=sensors)
        print(f"SOP ID:         {plan.get('sop_id')}")
        print(f"Risk Level:     {plan.get('risk_level')}")
        print(f"Reversible:     {plan.get('is_reversible')}")
        print(f"Action:         {plan.get('recommended_action')}")
        print(f"Steps:          {plan.get('action_steps')}")
        print(f"Outcome:        {plan.get('expected_outcome')}")

    print("\n" + "=" * 70)
    print("PHASE 4 COMPLETED SUCCESSFULLY: RAG retrieval & plan synthesis verified.")
    print("=" * 70)
