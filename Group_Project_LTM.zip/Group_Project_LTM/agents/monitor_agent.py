"""
MonitorAgent — Satellite Telemetry Anomaly Detection
====================================================
Phase 2 Agent:
1. Reconstructs temporal telemetry windows using Autoencoder backbone.
2. Identifies top-deviated sensors via per-channel MSE attribution.
3. Invokes LLM reasoning layer to synthesize structured anomaly report.
"""

import sys
from pathlib import Path
import numpy as np
import json

ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from data_loader import SENSOR_COLUMNS, BASE_DIR
from preprocessing import prepare_ad_windows, TelemetryNormalizer
from models.autoencoder import TelemetryAnomalyDetector
from agents.llm_client import LLMClient

MODEL_PATH = BASE_DIR / "artifacts" / "models" / "monitor_autoencoder.pt"


class MonitorAgent:
    def __init__(self, detector: TelemetryAnomalyDetector = None, normalizer: TelemetryNormalizer = None):
        self.detector = detector
        self.normalizer = normalizer
        self.llm = LLMClient()
        self.feature_columns = SENSOR_COLUMNS

    def train_backbone(self, X_train: np.ndarray, epochs: int = 8, batch_size: int = 64):
        """Trains the underlying deep autoencoder strictly on normal telemetry."""
        if self.detector is None:
            self.detector = TelemetryAnomalyDetector(
                in_features=len(self.feature_columns),
                window_size=X_train.shape[1],
                latent_dim=32,
            )
        self.detector.fit(X_train, epochs=epochs, batch_size=batch_size)
        MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
        self.detector.save(MODEL_PATH)

    def load_backbone(self, model_path: Path = MODEL_PATH):
        self.detector = TelemetryAnomalyDetector.load(model_path)

    def analyze_window(self, window: np.ndarray) -> dict:
        """
        Analyzes a single telemetry window of shape (W, D) or (1, W, D).
        Returns a structured LLM anomaly report.
        """
        if self.detector is None:
            raise RuntimeError("MonitorAgent backbone detector is not initialized or trained.")

        if window.ndim == 2:
            X = np.expand_dims(window, axis=0)  # (1, W, D)
        elif window.ndim == 3:
            X = window
        else:
            raise ValueError(f"Expected 2D or 3D window, got shape {window.shape}")

        # Compute reconstruction metrics
        anomaly_score = float(self.detector.predict_anomaly_scores(X)[0])
        threshold = float(self.detector.threshold)
        sensor_errors = self.detector.compute_sensor_errors(X)[0]  # (D,)

        # Rank sensors by reconstruction error
        top_indices = np.argsort(sensor_errors)[::-1][:5]
        top_sensors = [
            {"sensor": self.feature_columns[idx], "error": round(float(sensor_errors[idx]), 5)}
            for idx in top_indices
        ]

        # Formulate prompt for LLM
        prompt = (
            f"Satellite Telemetry Monitor Agent Analysis:\n"
            f"- Anomaly Reconstruction Score: {anomaly_score:.5f}\n"
            f"- Operational Limit Threshold: {threshold:.5f}\n"
            f"- Status: {'ANOMALOUS (Exceeds Threshold)' if anomaly_score > threshold else 'NOMINAL'}\n"
            f"- Top Deviating Channels: {json.dumps(top_sensors)}\n\n"
            f"Generate a structured JSON anomaly report with fields: is_anomaly (bool), confidence (0.0-1.0), "
            f"affected_sensors (list of strings), and rationale (concise engineering explanation)."
        )

        report = self.llm.generate(
            prompt=prompt,
            task_type="monitor",
            anomaly_score=anomaly_score,
            threshold=threshold,
            top_sensors=top_sensors,
        )

        report["raw_anomaly_score"] = round(anomaly_score, 5)
        report["raw_threshold"] = round(threshold, 5)
        report["sensor_deviations"] = top_sensors
        return report


if __name__ == "__main__":
    print("=" * 70)
    print("PHASE 2 VALIDATION: MONITOR AGENT (BACKBONE + LLM LAYER)")
    print("=" * 70)

    # 1. Load data
    print("\n--- 1. Preparing Data for MonitorAgent ---")
    X_train, y_train, X_test, y_test, normalizer = prepare_ad_windows(
        window_size=60,
        train_step=60,
        test_step=60,
        max_train_windows=1500,
        max_test_windows=1500,
    )

    # 2. Train Backbone
    print("\n--- 2. Training Autoencoder Backbone ---")
    agent = MonitorAgent(normalizer=normalizer)
    agent.train_backbone(X_train, epochs=6, batch_size=64)

    # 3. Quantitative Evaluation
    print("\n--- 3. Quantitative Evaluation on AD_Test ---")
    metrics = agent.detector.evaluate(X_test, y_test)
    for k, v in metrics.items():
        print(f"  {k}: {v}")

    # 4. LLM Layer Anomaly Reports
    print("\n--- 4. LLM Layer Inference on Sample Windows ---")
    
    # Find a normal sample (y=0) and an anomaly sample (y=1)
    norm_idx = np.where(y_test == 0)[0][0] if 0 in y_test else 0
    anom_idx = np.where(y_test == 1)[0][0] if 1 in y_test else -1

    print("\n[Sample 1: Nominal Telemetry Window]")
    norm_report = agent.analyze_window(X_test[norm_idx])
    print(json.dumps(norm_report, indent=2))

    if anom_idx != -1:
        print("\n[Sample 2: Anomalous Telemetry Window]")
        anom_report = agent.analyze_window(X_test[anom_idx])
        print(json.dumps(anom_report, indent=2))

    print("\n" + "=" * 70)
    print("PHASE 2 COMPLETED SUCCESSFULLY: MonitorAgent trained and verified.")
    print("=" * 70)
