"""
Satellite Subsystem Standard Operating Procedures (SOPs) & RAG Knowledge Base
"""
