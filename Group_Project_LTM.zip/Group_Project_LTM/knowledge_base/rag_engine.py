"""
RAG Engine for Satellite Contingency Recovery Procedures
=========================================================
Implements lexical and semantic indexing over spacecraft subsystem SOPs,
enabling precise retrieval grounded in diagnosed fault classes and sensor channels.
"""

from pathlib import Path
import json
import re
from typing import Optional

SOP_FILE = Path(__file__).resolve().parent / "sops.json"


class SOPKnowledgeBase:
    def __init__(self, sops_path: Path = SOP_FILE):
        self.sops_path = sops_path
        self.documents = []
        self.load()

    def load(self):
        if not self.sops_path.exists():
            raise FileNotFoundError(f"SOP database not found: {self.sops_path}")
        with open(self.sops_path, "r", encoding="utf-8") as f:
            data = json.load(f)
            self.documents = data.get("sops", [])
        print(f"[RAG Engine] Loaded {len(self.documents)} Standard Operating Procedures.")

    def retrieve(self, query: str, top_k: int = 1) -> list[dict]:
        """
        Retrieves the top-k matching SOPs for a given query (e.g. diagnosed fault name).
        Scores matches based on token overlap, subsystem match, and exact class match.
        """
        if not self.documents:
            return []

        query_tokens = set(re.findall(r"\w+", query.lower()))
        scored_docs = []

        for doc in self.documents:
            doc_text = f"{doc.get('sop_id', '')} {doc.get('class_name', '')} {doc.get('subsystem', '')} {doc.get('title', '')} {' '.join(doc.get('steps', []))}".lower()
            doc_tokens = set(re.findall(r"\w+", doc_text))

            score = 0.0
            # Exact class name match gets highest boost
            if doc.get("class_name", "").lower() in query.lower():
                score += 10.0
            if query.lower() in doc.get("class_name", "").lower():
                score += 8.0

            # Subsystem match boost
            subsystem = doc.get("subsystem", "").lower()
            for token in query_tokens:
                if token in subsystem:
                    score += 3.0

            # Lexical overlap
            overlap = query_tokens.intersection(doc_tokens)
            score += len(overlap) * 1.0

            scored_docs.append((score, doc))

        # Sort descending by score
        scored_docs.sort(key=lambda x: x[0], reverse=True)
        results = []
        for score, doc in scored_docs[:top_k]:
            doc_copy = dict(doc)
            doc_copy["retrieval_score"] = round(float(score), 3)
            results.append(doc_copy)

        return results


# Global singleton instance
_kb_instance: Optional[SOPKnowledgeBase] = None

def get_knowledge_base() -> SOPKnowledgeBase:
    global _kb_instance
    if _kb_instance is None:
        _kb_instance = SOPKnowledgeBase()
    return _kb_instance
