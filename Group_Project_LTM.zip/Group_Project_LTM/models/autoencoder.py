"""
Autoencoder for Reconstruction-Based Anomaly Detection (MonitorAgent Backbone)
==============================================================================
Implements:
1. PyTorch 1D-Convolutional / LSTM Autoencoder for temporal telemetry sequences.
2. Robust PCA-based subspace Autoencoder fallback when PyTorch is unavailable.
3. Reconstruction error scoring and per-sensor attribution.
4. Percentile-based threshold calibration on normal validation data.
"""

from pathlib import Path
import json
import numpy as np
from sklearn.metrics import precision_recall_fscore_support, roc_auc_score
import joblib

try:
    import torch
    import torch.nn as nn
    from torch.utils.data import DataLoader, TensorDataset
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False


# ---------------------------------------------------------------------------
# PyTorch Temporal Autoencoder
# ---------------------------------------------------------------------------
if HAS_TORCH:
    class Conv1DAutoencoder(nn.Module):
        """
        1D-Convolutional Autoencoder for multi-channel satellite telemetry windows.
        Input shape: (Batch, Channels/Features, Time)
        """
        def __init__(self, in_channels: int = 33, latent_dim: int = 32):
            super().__init__()
            # Encoder
            self.encoder = nn.Sequential(
                nn.Conv1d(in_channels, 64, kernel_size=5, stride=2, padding=2),
                nn.BatchNorm1d(64),
                nn.LeakyReLU(0.2),
                nn.Conv1d(64, latent_dim, kernel_size=5, stride=2, padding=2),
                nn.BatchNorm1d(latent_dim),
                nn.LeakyReLU(0.2),
            )
            # Decoder
            self.decoder = nn.Sequential(
                nn.ConvTranspose1d(latent_dim, 64, kernel_size=5, stride=2, padding=2, output_padding=1),
                nn.BatchNorm1d(64),
                nn.LeakyReLU(0.2),
                nn.ConvTranspose1d(64, in_channels, kernel_size=5, stride=2, padding=2, output_padding=1),
            )

        def forward(self, x: torch.Tensor) -> torch.Tensor:
            # x: (B, C, T)
            z = self.encoder(x)
            out = self.decoder(z)
            # Match original temporal length if off by 1 due to padding
            if out.shape[-1] != x.shape[-1]:
                out = nn.functional.interpolate(out, size=x.shape[-1], mode="linear", align_corners=False)
            return out


# ---------------------------------------------------------------------------
# Fallback Subspace Autoencoder (Numpy/Scikit-learn)
# ---------------------------------------------------------------------------
class SubspaceAutoencoder:
    """PCA / Singular Value projection autoencoder fallback."""
    def __init__(self, n_components: int = 16):
        self.n_components = n_components
        self.mean_ = None
        self.components_ = None

    def fit(self, X: np.ndarray):
        # X: (N, W, D) -> Flatten across time or per-time
        N, W, D = X.shape
        flat = X.reshape(N, W * D)
        self.mean_ = np.mean(flat, axis=0)
        centered = flat - self.mean_
        _, _, Vt = np.linalg.svd(centered, full_matrices=False)
        self.components_ = Vt[:self.n_components]

    def reconstruct(self, X: np.ndarray) -> np.ndarray:
        N, W, D = X.shape
        flat = X.reshape(N, W * D)
        centered = flat - self.mean_
        z = np.dot(centered, self.components_.T)
        recon_flat = np.dot(z, self.components_) + self.mean_
        return recon_flat.reshape(N, W, D)


# ---------------------------------------------------------------------------
# Unified Anomaly Detector Model
# ---------------------------------------------------------------------------
class TelemetryAnomalyDetector:
    def __init__(self, in_features: int = 33, window_size: int = 60, latent_dim: int = 32, use_torch: bool = True):
        self.in_features = in_features
        self.window_size = window_size
        self.latent_dim = latent_dim
        self.use_torch = use_torch and HAS_TORCH
        self.threshold = 1.0

        if self.use_torch:
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
            self.model = Conv1DAutoencoder(in_channels=in_features, latent_dim=latent_dim).to(self.device)
        else:
            self.device = "cpu"
            self.model = SubspaceAutoencoder(n_components=latent_dim)

    def fit(
        self,
        X_train: np.ndarray,
        epochs: int = 10,
        batch_size: int = 64,
        lr: float = 1e-3,
        val_split: float = 0.1,
    ):
        """Fits autoencoder strictly on normal training telemetry."""
        if len(X_train) == 0:
            raise ValueError("Training dataset is empty.")

        # Split train / val
        val_size = int(len(X_train) * val_split)
        if val_size > 0:
            X_val = X_train[-val_size:]
            X_tr = X_train[:-val_size]
        else:
            X_tr = X_train
            X_val = X_train

        if self.use_torch:
            print(f"[MonitorModel] Training PyTorch Conv1D Autoencoder on {self.device} for {epochs} epochs...")
            # Reshape (N, W, D) -> (N, D, W) for Conv1D
            tr_t = torch.tensor(X_tr.transpose(0, 2, 1), dtype=torch.float32)
            dataset = TensorDataset(tr_t, tr_t)
            loader = DataLoader(dataset, batch_size=batch_size, shuffle=True)

            optimizer = torch.optim.Adam(self.model.parameters(), lr=lr)
            criterion = nn.MSELoss()

            self.model.train()
            for epoch in range(1, epochs + 1):
                total_loss = 0.0
                for batch_x, _ in loader:
                    batch_x = batch_x.to(self.device)
                    optimizer.zero_grad()
                    out = self.model(batch_x)
                    loss = criterion(out, batch_x)
                    loss.backward()
                    optimizer.step()
                    total_loss += loss.item() * len(batch_x)
                avg_loss = total_loss / len(X_tr)
                if epoch % max(1, epochs // 5) == 0 or epoch == epochs:
                    print(f"  Epoch {epoch:02d}/{epochs:02d} | Train MSE: {avg_loss:.5f}")
        else:
            print(f"[MonitorModel] Fitting Subspace Autoencoder (Numpy/SVD)...")
            self.model.fit(X_tr)

        # Calibrate threshold on validation normal data
        self.calibrate_threshold(X_val, percentile=95.0)

    def reconstruct(self, X: np.ndarray) -> np.ndarray:
        """Returns reconstructed telemetry with shape (N, W, D)."""
        if self.use_torch:
            self.model.eval()
            with torch.no_grad():
                # (N, W, D) -> (N, D, W)
                x_t = torch.tensor(X.transpose(0, 2, 1), dtype=torch.float32).to(self.device)
                out = self.model(x_t)
                recon = out.cpu().numpy().transpose(0, 2, 1)
                return recon
        else:
            return self.model.reconstruct(X)

    def compute_sensor_errors(self, X: np.ndarray) -> np.ndarray:
        """
        Computes mean squared error per sensor feature.
        Returns shape (N, D) where D is number of sensor columns.
        """
        recon = self.reconstruct(X)
        # Squared error per timestep and sensor: (N, W, D)
        sq_err = (X - recon) ** 2
        # Average over temporal window W -> (N, D)
        return np.mean(sq_err, axis=1)

    def predict_anomaly_scores(self, X: np.ndarray) -> np.ndarray:
        """
        Computes overall anomaly score (mean squared error across all sensors and timesteps).
        Returns shape (N,)
        """
        sensor_errors = self.compute_sensor_errors(X)
        return np.mean(sensor_errors, axis=1)

    def calibrate_threshold(self, X_normal_val: np.ndarray, percentile: float = 95.0):
        """Sets anomaly threshold based on normal validation reconstruction score percentile."""
        scores = self.predict_anomaly_scores(X_normal_val)
        self.threshold = float(np.percentile(scores, percentile))
        print(f"[MonitorModel] Calibrated threshold (p={percentile}%): {self.threshold:.5f} (Min: {scores.min():.5f}, Max: {scores.max():.5f})")

    def predict(self, X: np.ndarray) -> np.ndarray:
        """Returns binary predictions: 1 = anomaly, 0 = normal."""
        scores = self.predict_anomaly_scores(X)
        return (scores > self.threshold).astype(int)

    def evaluate(self, X_test: np.ndarray, y_test: np.ndarray) -> dict:
        """Evaluates model performance against test labels."""
        scores = self.predict_anomaly_scores(X_test)
        preds = (scores > self.threshold).astype(int)

        precision, recall, f1, _ = precision_recall_fscore_support(
            y_test, preds, average="binary", zero_division=0
        )
        try:
            auc = roc_auc_score(y_test, scores)
        except Exception:
            auc = 0.5

        metrics = {
            "precision": float(precision),
            "recall": float(recall),
            "f1": float(f1),
            "roc_auc": float(auc),
            "threshold": float(self.threshold),
            "num_test_samples": int(len(y_test)),
            "actual_anomalies": int(np.sum(y_test)),
            "predicted_anomalies": int(np.sum(preds)),
        }
        return metrics

    def save(self, filepath: Path):
        filepath = Path(filepath)
        filepath.parent.mkdir(parents=True, exist_ok=True)
        if self.use_torch:
            torch.save({
                "state_dict": self.model.state_dict(),
                "in_features": self.in_features,
                "window_size": self.window_size,
                "latent_dim": self.latent_dim,
                "threshold": self.threshold,
                "use_torch": True,
            }, filepath)
        else:
            joblib.dump({
                "model": self.model,
                "in_features": self.in_features,
                "window_size": self.window_size,
                "latent_dim": self.latent_dim,
                "threshold": self.threshold,
                "use_torch": False,
            }, filepath)
        print(f"[MonitorModel] Model saved to {filepath}")

    @classmethod
    def load(cls, filepath: Path) -> "TelemetryAnomalyDetector":
        filepath = Path(filepath)
        if not filepath.exists():
            raise FileNotFoundError(f"Model file not found: {filepath}")

        # Try loading torch checkpoint
        if HAS_TORCH:
            try:
                checkpoint = torch.load(filepath, map_location="cpu")
                if isinstance(checkpoint, dict) and "state_dict" in checkpoint:
                    obj = cls(
                        in_features=checkpoint["in_features"],
                        window_size=checkpoint["window_size"],
                        latent_dim=checkpoint["latent_dim"],
                        use_torch=True,
                    )
                    obj.model.load_state_dict(checkpoint["state_dict"])
                    obj.threshold = checkpoint["threshold"]
                    return obj
            except Exception:
                pass

        # Fallback joblib load
        data = joblib.load(filepath)
        obj = cls(
            in_features=data["in_features"],
            window_size=data["window_size"],
            latent_dim=data["latent_dim"],
            use_torch=False,
        )
        obj.model = data["model"]
        obj.threshold = data["threshold"]
        return obj
