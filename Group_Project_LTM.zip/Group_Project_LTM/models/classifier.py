"""
1D-CNN & Feature Ensemble Classifier for 18-Class Fault Diagnosis
================================================================
Implements:
1. PyTorch 1D-CNN temporal classifier for 18-class satellite telemetry faults.
2. Lightweight Scikit-Learn Ensemble classifier fallback on window summary features.
3. Multiclass evaluation with per-class precision/recall/F1 and confusion matrix.
"""

from pathlib import Path
import numpy as np
from sklearn.metrics import classification_report, confusion_matrix, precision_recall_fscore_support
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
import joblib

try:
    import torch
    import torch.nn as nn
    from torch.utils.data import DataLoader, TensorDataset
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False


# ---------------------------------------------------------------------------
# PyTorch 1D-CNN Classifier
# ---------------------------------------------------------------------------
if HAS_TORCH:
    class Conv1DClassifier(nn.Module):
        """
        Multi-channel 1D-CNN for temporal fault signature identification.
        Input: (Batch, Channels/Features=33, Time=60)
        """
        def __init__(self, in_channels: int = 33, num_classes: int = 18):
            super().__init__()
            self.features = nn.Sequential(
                nn.Conv1d(in_channels, 64, kernel_size=5, padding=2),
                nn.BatchNorm1d(64),
                nn.ReLU(),
                nn.MaxPool1d(2),

                nn.Conv1d(64, 128, kernel_size=5, padding=2),
                nn.BatchNorm1d(128),
                nn.ReLU(),
                nn.MaxPool1d(2),

                nn.Conv1d(128, 128, kernel_size=3, padding=1),
                nn.BatchNorm1d(128),
                nn.ReLU(),
                nn.AdaptiveAvgPool1d(1),
            )
            self.classifier = nn.Sequential(
                nn.Flatten(),
                nn.Dropout(0.3),
                nn.Linear(128, 64),
                nn.ReLU(),
                nn.Linear(64, num_classes),
            )

        def forward(self, x: torch.Tensor) -> torch.Tensor:
            feats = self.features(x)
            logits = self.classifier(feats)
            return logits


# ---------------------------------------------------------------------------
# Feature Extractor for Tabular Fallback
# ---------------------------------------------------------------------------
def extract_window_features(X: np.ndarray) -> np.ndarray:
    """
    Extracts summary statistics (mean, std, min, max, energy) across time.
    X: (N, W, D) -> returns (N, D * 5)
    """
    mean_feat = np.mean(X, axis=1)
    std_feat = np.std(X, axis=1)
    min_feat = np.min(X, axis=1)
    max_feat = np.max(X, axis=1)
    energy_feat = np.mean(X ** 2, axis=1)
    features = np.hstack([mean_feat, std_feat, min_feat, max_feat, energy_feat])
    return np.nan_to_num(features, nan=0.0, posinf=1e5, neginf=-1e5)


# ---------------------------------------------------------------------------
# Unified Fault Diagnosis Classifier
# ---------------------------------------------------------------------------
class TelemetryFaultClassifier:
    def __init__(self, in_features: int = 33, num_classes: int = 18, use_torch: bool = True):
        self.in_features = in_features
        self.num_classes = num_classes
        self.use_torch = use_torch and HAS_TORCH

        if self.use_torch:
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
            self.model = Conv1DClassifier(in_channels=in_features, num_classes=num_classes).to(self.device)
        else:
            self.device = "cpu"
            self.model = RandomForestClassifier(n_estimators=100, max_depth=15, random_state=42)

    def fit(
        self,
        X_train: np.ndarray,
        y_train: np.ndarray,
        epochs: int = 12,
        batch_size: int = 64,
        lr: float = 1e-3,
    ):
        """Trains the 18-class classifier on windowed telemetry."""
        if len(X_train) == 0:
            raise ValueError("Training dataset is empty.")

        if self.use_torch:
            print(f"[DiagnosisModel] Training PyTorch 1D-CNN on {self.device} for {epochs} epochs...")
            # Reshape (N, W, D) -> (N, D, W)
            tr_t = torch.tensor(X_train.transpose(0, 2, 1), dtype=torch.float32)
            lbl_t = torch.tensor(y_train, dtype=torch.long)
            dataset = TensorDataset(tr_t, lbl_t)
            loader = DataLoader(dataset, batch_size=batch_size, shuffle=True)

            optimizer = torch.optim.AdamW(self.model.parameters(), lr=lr, weight_decay=1e-4)
            criterion = nn.CrossEntropyLoss()

            self.model.train()
            for epoch in range(1, epochs + 1):
                total_loss = 0.0
                correct = 0
                total = 0
                for batch_x, batch_y in loader:
                    batch_x, batch_y = batch_x.to(self.device), batch_y.to(self.device)
                    optimizer.zero_grad()
                    logits = self.model(batch_x)
                    loss = criterion(logits, batch_y)
                    loss.backward()
                    optimizer.step()

                    total_loss += loss.item() * len(batch_x)
                    preds = torch.argmax(logits, dim=1)
                    correct += (preds == batch_y).sum().item()
                    total += len(batch_x)

                acc = correct / total if total > 0 else 0
                if epoch % max(1, epochs // 4) == 0 or epoch == epochs:
                    print(f"  Epoch {epoch:02d}/{epochs:02d} | Loss: {total_loss/total:.4f} | Train Acc: {acc*100:.2f}%")
        else:
            print("[DiagnosisModel] Training Random Forest on summary features...")
            feats = extract_window_features(X_train)
            self.model.fit(feats, y_train)

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        """Returns class probabilities of shape (N, num_classes)."""
        if self.use_torch:
            self.model.eval()
            with torch.no_grad():
                x_t = torch.tensor(X.transpose(0, 2, 1), dtype=torch.float32).to(self.device)
                logits = self.model(x_t)
                probs = torch.softmax(logits, dim=1).cpu().numpy()
                return probs
        else:
            feats = extract_window_features(X)
            # Ensure output shape has all classes
            probs = self.model.predict_proba(feats)
            if probs.shape[1] < self.num_classes:
                full_probs = np.zeros((len(X), self.num_classes))
                for idx, c in enumerate(self.model.classes_):
                    full_probs[:, c] = probs[:, idx]
                return full_probs
            return probs

    def predict(self, X: np.ndarray) -> np.ndarray:
        probs = self.predict_proba(X)
        return np.argmax(probs, axis=1)

    def evaluate(self, X_test: np.ndarray, y_test: np.ndarray, class_names: list[str] = None) -> dict:
        """Calculates per-class metrics and confusion matrix."""
        probs = self.predict_proba(X_test)
        preds = np.argmax(probs, axis=1)

        accuracy = float(np.mean(preds == y_test))
        cm = confusion_matrix(y_test, preds, labels=list(range(self.num_classes)))

        report = classification_report(
            y_test, preds,
            target_names=[class_names[i] if class_names and i < len(class_names) else f"Class_{i}" for i in range(self.num_classes)],
            output_dict=True,
            zero_division=0,
        )

        return {
            "overall_accuracy": accuracy,
            "classification_report": report,
            "confusion_matrix": cm.tolist(),
        }

    def save(self, filepath: Path):
        filepath = Path(filepath)
        filepath.parent.mkdir(parents=True, exist_ok=True)
        if self.use_torch:
            torch.save({
                "state_dict": self.model.state_dict(),
                "in_features": self.in_features,
                "num_classes": self.num_classes,
                "use_torch": True,
            }, filepath)
        else:
            joblib.dump({
                "model": self.model,
                "in_features": self.in_features,
                "num_classes": self.num_classes,
                "use_torch": False,
            }, filepath)
        print(f"[DiagnosisModel] Model saved to {filepath}")

    @classmethod
    def load(cls, filepath: Path) -> "TelemetryFaultClassifier":
        filepath = Path(filepath)
        if not filepath.exists():
            raise FileNotFoundError(f"Model file not found: {filepath}")

        if HAS_TORCH:
            try:
                checkpoint = torch.load(filepath, map_location="cpu")
                if isinstance(checkpoint, dict) and "state_dict" in checkpoint:
                    obj = cls(
                        in_features=checkpoint["in_features"],
                        num_classes=checkpoint["num_classes"],
                        use_torch=True,
                    )
                    obj.model.load_state_dict(checkpoint["state_dict"])
                    return obj
            except Exception:
                pass

        data = joblib.load(filepath)
        obj = cls(
            in_features=data["in_features"],
            num_classes=data["num_classes"],
            use_torch=False,
        )
        obj.model = data["model"]
        return obj
